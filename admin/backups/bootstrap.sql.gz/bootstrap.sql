--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4 (Debian 14.4-1.pgdg110+1)
-- Dumped by pg_dump version 14.4 (Debian 14.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.addresses (
    id integer NOT NULL,
    "ownerId" integer,
    "countryCode" character varying(255) NOT NULL,
    "administrativeArea" character varying(255),
    locality character varying(255),
    "dependentLocality" character varying(255),
    "postalCode" character varying(255),
    "sortingCode" character varying(255),
    "addressLine1" character varying(255),
    "addressLine2" character varying(255),
    organization character varying(255),
    "organizationTaxId" character varying(255),
    "fullName" character varying(255),
    "firstName" character varying(255),
    "lastName" character varying(255),
    latitude character varying(255),
    longitude character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.addresses OWNER TO db;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "pluginId" integer,
    heading character varying(255) NOT NULL,
    body text NOT NULL,
    unread boolean DEFAULT true NOT NULL,
    "dateRead" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.announcements OWNER TO db;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcements_id_seq OWNER TO db;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: assetindexdata; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.assetindexdata (
    id integer NOT NULL,
    "sessionId" integer NOT NULL,
    "volumeId" integer NOT NULL,
    uri text,
    size bigint,
    "timestamp" timestamp(0) without time zone,
    "isDir" boolean DEFAULT false,
    "recordId" integer,
    "isSkipped" boolean DEFAULT false,
    "inProgress" boolean DEFAULT false,
    completed boolean DEFAULT false,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.assetindexdata OWNER TO db;

--
-- Name: assetindexdata_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.assetindexdata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assetindexdata_id_seq OWNER TO db;

--
-- Name: assetindexdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.assetindexdata_id_seq OWNED BY public.assetindexdata.id;


--
-- Name: assetindexingsessions; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.assetindexingsessions (
    id integer NOT NULL,
    "indexedVolumes" text,
    "totalEntries" integer,
    "processedEntries" integer DEFAULT 0 NOT NULL,
    "cacheRemoteImages" boolean,
    "isCli" boolean DEFAULT false,
    "actionRequired" boolean DEFAULT false,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.assetindexingsessions OWNER TO db;

--
-- Name: assetindexingsessions_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.assetindexingsessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assetindexingsessions_id_seq OWNER TO db;

--
-- Name: assetindexingsessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.assetindexingsessions_id_seq OWNED BY public.assetindexingsessions.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    "volumeId" integer,
    "folderId" integer NOT NULL,
    "uploaderId" integer,
    filename character varying(255) NOT NULL,
    kind character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    alt text,
    width integer,
    height integer,
    size bigint,
    "focalPoint" character varying(13) DEFAULT NULL::character varying,
    "deletedWithVolume" boolean,
    "keptFile" boolean,
    "dateModified" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.assets OWNER TO db;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "parentId" integer,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO db;

--
-- Name: categorygroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.categorygroups (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "defaultPlacement" character varying(255) DEFAULT 'end'::character varying NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "categorygroups_defaultPlacement_check" CHECK ((("defaultPlacement")::text = ANY (ARRAY[('beginning'::character varying)::text, ('end'::character varying)::text])))
);


ALTER TABLE public.categorygroups OWNER TO db;

--
-- Name: categorygroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.categorygroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorygroups_id_seq OWNER TO db;

--
-- Name: categorygroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.categorygroups_id_seq OWNED BY public.categorygroups.id;


--
-- Name: categorygroups_sites; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.categorygroups_sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.categorygroups_sites OWNER TO db;

--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.categorygroups_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorygroups_sites_id_seq OWNER TO db;

--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.categorygroups_sites_id_seq OWNED BY public.categorygroups_sites.id;


--
-- Name: changedattributes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.changedattributes (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    attribute character varying(255) NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


ALTER TABLE public.changedattributes OWNER TO db;

--
-- Name: changedfields; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.changedfields (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


ALTER TABLE public.changedfields OWNER TO db;

--
-- Name: content; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.content (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    title character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    "field_testField_uuqdrllc" text
);


ALTER TABLE public.content OWNER TO db;

--
-- Name: content_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.content_id_seq OWNER TO db;

--
-- Name: content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.content_id_seq OWNED BY public.content.id;


--
-- Name: craftidtokens; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.craftidtokens (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "accessToken" text NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.craftidtokens OWNER TO db;

--
-- Name: craftidtokens_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.craftidtokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.craftidtokens_id_seq OWNER TO db;

--
-- Name: craftidtokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.craftidtokens_id_seq OWNED BY public.craftidtokens.id;


--
-- Name: deprecationerrors; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.deprecationerrors (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    "lastOccurrence" timestamp(0) without time zone NOT NULL,
    file character varying(255) NOT NULL,
    line smallint,
    message text,
    traces text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.deprecationerrors OWNER TO db;

--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.deprecationerrors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deprecationerrors_id_seq OWNER TO db;

--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.deprecationerrors_id_seq OWNED BY public.deprecationerrors.id;


--
-- Name: drafts; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.drafts (
    id integer NOT NULL,
    "canonicalId" integer,
    "creatorId" integer,
    provisional boolean DEFAULT false NOT NULL,
    name character varying(255) NOT NULL,
    notes text,
    "trackChanges" boolean DEFAULT false NOT NULL,
    "dateLastMerged" timestamp(0) without time zone,
    saved boolean DEFAULT true NOT NULL
);


ALTER TABLE public.drafts OWNER TO db;

--
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.drafts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drafts_id_seq OWNER TO db;

--
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.drafts_id_seq OWNED BY public.drafts.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    "canonicalId" integer,
    "draftId" integer,
    "revisionId" integer,
    "fieldLayoutId" integer,
    type character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateLastMerged" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.elements OWNER TO db;

--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.elements_id_seq OWNER TO db;

--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: elements_sites; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.elements_sites (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    slug character varying(255),
    uri character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.elements_sites OWNER TO db;

--
-- Name: elements_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.elements_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.elements_sites_id_seq OWNER TO db;

--
-- Name: elements_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.elements_sites_id_seq OWNED BY public.elements_sites.id;


--
-- Name: entries; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "parentId" integer,
    "typeId" integer NOT NULL,
    "authorId" integer,
    "postDate" timestamp(0) without time zone,
    "expiryDate" timestamp(0) without time zone,
    "deletedWithEntryType" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.entries OWNER TO db;

--
-- Name: entrytypes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.entrytypes (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "hasTitleField" boolean DEFAULT true NOT NULL,
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    "titleFormat" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.entrytypes OWNER TO db;

--
-- Name: entrytypes_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.entrytypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entrytypes_id_seq OWNER TO db;

--
-- Name: entrytypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.entrytypes_id_seq OWNED BY public.entrytypes.id;


--
-- Name: fieldgroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.fieldgroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.fieldgroups OWNER TO db;

--
-- Name: fieldgroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.fieldgroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fieldgroups_id_seq OWNER TO db;

--
-- Name: fieldgroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.fieldgroups_id_seq OWNED BY public.fieldgroups.id;


--
-- Name: fieldlayoutfields; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.fieldlayoutfields (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    "tabId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    required boolean DEFAULT false NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.fieldlayoutfields OWNER TO db;

--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.fieldlayoutfields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fieldlayoutfields_id_seq OWNER TO db;

--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.fieldlayoutfields_id_seq OWNED BY public.fieldlayoutfields.id;


--
-- Name: fieldlayouts; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.fieldlayouts (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.fieldlayouts OWNER TO db;

--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.fieldlayouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fieldlayouts_id_seq OWNER TO db;

--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.fieldlayouts_id_seq OWNED BY public.fieldlayouts.id;


--
-- Name: fieldlayouttabs; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.fieldlayouttabs (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    name character varying(255) NOT NULL,
    settings text,
    elements text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.fieldlayouttabs OWNER TO db;

--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.fieldlayouttabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fieldlayouttabs_id_seq OWNER TO db;

--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.fieldlayouttabs_id_seq OWNED BY public.fieldlayouttabs.id;


--
-- Name: fields; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.fields (
    id integer NOT NULL,
    "groupId" integer,
    name character varying(255) NOT NULL,
    handle character varying(64) NOT NULL,
    context character varying(255) DEFAULT 'global'::character varying NOT NULL,
    "columnSuffix" character(8),
    instructions text,
    searchable boolean DEFAULT true NOT NULL,
    "translationMethod" character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "translationKeyFormat" text,
    type character varying(255) NOT NULL,
    settings text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.fields OWNER TO db;

--
-- Name: fields_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fields_id_seq OWNER TO db;

--
-- Name: fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.fields_id_seq OWNED BY public.fields.id;


--
-- Name: globalsets; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.globalsets (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.globalsets OWNER TO db;

--
-- Name: globalsets_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.globalsets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.globalsets_id_seq OWNER TO db;

--
-- Name: globalsets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.globalsets_id_seq OWNED BY public.globalsets.id;


--
-- Name: gqlschemas; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.gqlschemas (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    scope text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.gqlschemas OWNER TO db;

--
-- Name: gqlschemas_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.gqlschemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gqlschemas_id_seq OWNER TO db;

--
-- Name: gqlschemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.gqlschemas_id_seq OWNED BY public.gqlschemas.id;


--
-- Name: gqltokens; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.gqltokens (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "accessToken" character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "lastUsed" timestamp(0) without time zone,
    "schemaId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.gqltokens OWNER TO db;

--
-- Name: gqltokens_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.gqltokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gqltokens_id_seq OWNER TO db;

--
-- Name: gqltokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.gqltokens_id_seq OWNED BY public.gqltokens.id;


--
-- Name: imagetransformindex; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.imagetransformindex (
    id integer NOT NULL,
    "assetId" integer NOT NULL,
    transformer character varying(255) DEFAULT NULL::character varying,
    filename character varying(255),
    format character varying(255),
    "transformString" character varying(255) NOT NULL,
    "fileExists" boolean DEFAULT false NOT NULL,
    "inProgress" boolean DEFAULT false NOT NULL,
    error boolean DEFAULT false NOT NULL,
    "dateIndexed" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.imagetransformindex OWNER TO db;

--
-- Name: imagetransformindex_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.imagetransformindex_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imagetransformindex_id_seq OWNER TO db;

--
-- Name: imagetransformindex_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.imagetransformindex_id_seq OWNED BY public.imagetransformindex.id;


--
-- Name: imagetransforms; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.imagetransforms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    mode character varying(255) DEFAULT 'crop'::character varying NOT NULL,
    "position" character varying(255) DEFAULT 'center-center'::character varying NOT NULL,
    width integer,
    height integer,
    format character varying(255),
    quality integer,
    interlace character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "parameterChangeTime" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT imagetransforms_interlace_check CHECK (((interlace)::text = ANY (ARRAY[('none'::character varying)::text, ('line'::character varying)::text, ('plane'::character varying)::text, ('partition'::character varying)::text]))),
    CONSTRAINT imagetransforms_mode_check CHECK (((mode)::text = ANY (ARRAY[('stretch'::character varying)::text, ('fit'::character varying)::text, ('crop'::character varying)::text]))),
    CONSTRAINT imagetransforms_position_check CHECK ((("position")::text = ANY (ARRAY[('top-left'::character varying)::text, ('top-center'::character varying)::text, ('top-right'::character varying)::text, ('center-left'::character varying)::text, ('center-center'::character varying)::text, ('center-right'::character varying)::text, ('bottom-left'::character varying)::text, ('bottom-center'::character varying)::text, ('bottom-right'::character varying)::text])))
);


ALTER TABLE public.imagetransforms OWNER TO db;

--
-- Name: imagetransforms_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.imagetransforms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imagetransforms_id_seq OWNER TO db;

--
-- Name: imagetransforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.imagetransforms_id_seq OWNED BY public.imagetransforms.id;


--
-- Name: info; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.info (
    id integer NOT NULL,
    version character varying(50) NOT NULL,
    "schemaVersion" character varying(15) NOT NULL,
    maintenance boolean DEFAULT false NOT NULL,
    "configVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "fieldVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.info OWNER TO db;

--
-- Name: info_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_id_seq OWNER TO db;

--
-- Name: info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.info_id_seq OWNED BY public.info.id;


--
-- Name: matrixblocks; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.matrixblocks (
    id integer NOT NULL,
    "primaryOwnerId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "typeId" integer NOT NULL,
    "deletedWithOwner" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.matrixblocks OWNER TO db;

--
-- Name: matrixblocks_owners; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.matrixblocks_owners (
    "blockId" integer NOT NULL,
    "ownerId" integer NOT NULL,
    "sortOrder" smallint NOT NULL
);


ALTER TABLE public.matrixblocks_owners OWNER TO db;

--
-- Name: matrixblocktypes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.matrixblocktypes (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.matrixblocktypes OWNER TO db;

--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.matrixblocktypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matrixblocktypes_id_seq OWNER TO db;

--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.matrixblocktypes_id_seq OWNED BY public.matrixblocktypes.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    track character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "applyTime" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.migrations OWNER TO db;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO db;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.plugins (
    id integer NOT NULL,
    handle character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    "schemaVersion" character varying(255) NOT NULL,
    "licenseKeyStatus" character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    "licensedEdition" character varying(255),
    "installDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "plugins_licenseKeyStatus_check" CHECK ((("licenseKeyStatus")::text = ANY (ARRAY[('valid'::character varying)::text, ('trial'::character varying)::text, ('invalid'::character varying)::text, ('mismatched'::character varying)::text, ('astray'::character varying)::text, ('unknown'::character varying)::text])))
);


ALTER TABLE public.plugins OWNER TO db;

--
-- Name: plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plugins_id_seq OWNER TO db;

--
-- Name: plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.plugins_id_seq OWNED BY public.plugins.id;


--
-- Name: projectconfig; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.projectconfig (
    path character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.projectconfig OWNER TO db;

--
-- Name: queue; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.queue (
    id integer NOT NULL,
    channel character varying(255) DEFAULT 'queue'::character varying NOT NULL,
    job bytea NOT NULL,
    description text,
    "timePushed" integer NOT NULL,
    ttr integer NOT NULL,
    delay integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 1024 NOT NULL,
    "dateReserved" timestamp(0) without time zone,
    "timeUpdated" integer,
    progress smallint DEFAULT 0 NOT NULL,
    "progressLabel" character varying(255),
    attempt integer,
    fail boolean DEFAULT false,
    "dateFailed" timestamp(0) without time zone,
    error text
);


ALTER TABLE public.queue OWNER TO db;

--
-- Name: queue_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.queue_id_seq OWNER TO db;

--
-- Name: queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.queue_id_seq OWNED BY public.queue.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.relations (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "sourceId" integer NOT NULL,
    "sourceSiteId" integer,
    "targetId" integer NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.relations OWNER TO db;

--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relations_id_seq OWNER TO db;

--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: resourcepaths; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.resourcepaths (
    hash character varying(255) NOT NULL,
    path character varying(255) NOT NULL
);


ALTER TABLE public.resourcepaths OWNER TO db;

--
-- Name: revisions; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.revisions (
    id integer NOT NULL,
    "canonicalId" integer NOT NULL,
    "creatorId" integer,
    num integer NOT NULL,
    notes text
);


ALTER TABLE public.revisions OWNER TO db;

--
-- Name: revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revisions_id_seq OWNER TO db;

--
-- Name: revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.revisions_id_seq OWNED BY public.revisions.id;


--
-- Name: searchindex; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.searchindex (
    "elementId" integer NOT NULL,
    attribute character varying(25) NOT NULL,
    "fieldId" integer NOT NULL,
    "siteId" integer NOT NULL,
    keywords text NOT NULL,
    keywords_vector tsvector NOT NULL
);


ALTER TABLE public.searchindex OWNER TO db;

--
-- Name: sections; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sections (
    id integer NOT NULL,
    "structureId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'channel'::character varying NOT NULL,
    "enableVersioning" boolean DEFAULT false NOT NULL,
    "propagationMethod" character varying(255) DEFAULT 'all'::character varying NOT NULL,
    "defaultPlacement" character varying(255) DEFAULT 'end'::character varying NOT NULL,
    "previewTargets" text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "sections_defaultPlacement_check" CHECK ((("defaultPlacement")::text = ANY (ARRAY[('beginning'::character varying)::text, ('end'::character varying)::text]))),
    CONSTRAINT sections_type_check CHECK (((type)::text = ANY (ARRAY[('single'::character varying)::text, ('channel'::character varying)::text, ('structure'::character varying)::text])))
);


ALTER TABLE public.sections OWNER TO db;

--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sections_id_seq OWNER TO db;

--
-- Name: sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.sections_id_seq OWNED BY public.sections.id;


--
-- Name: sections_sites; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sections_sites (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "enabledByDefault" boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.sections_sites OWNER TO db;

--
-- Name: sections_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.sections_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sections_sites_id_seq OWNER TO db;

--
-- Name: sections_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.sections_sites_id_seq OWNED BY public.sections_sites.id;


--
-- Name: sequences; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sequences (
    name character varying(255) NOT NULL,
    next integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.sequences OWNER TO db;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token character(100) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.sessions OWNER TO db;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessions_id_seq OWNER TO db;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: shunnedmessages; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.shunnedmessages (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    message character varying(255) NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.shunnedmessages OWNER TO db;

--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.shunnedmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shunnedmessages_id_seq OWNER TO db;

--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.shunnedmessages_id_seq OWNED BY public.shunnedmessages.id;


--
-- Name: sitegroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sitegroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.sitegroups OWNER TO db;

--
-- Name: sitegroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.sitegroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sitegroups_id_seq OWNER TO db;

--
-- Name: sitegroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.sitegroups_id_seq OWNED BY public.sitegroups.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "primary" boolean NOT NULL,
    enabled character varying(255) DEFAULT 'true'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    language character varying(12) NOT NULL,
    "hasUrls" boolean DEFAULT false NOT NULL,
    "baseUrl" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.sites OWNER TO db;

--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sites_id_seq OWNER TO db;

--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: structureelements; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.structureelements (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "elementId" integer,
    root integer,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    level smallint NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.structureelements OWNER TO db;

--
-- Name: structureelements_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.structureelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.structureelements_id_seq OWNER TO db;

--
-- Name: structureelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.structureelements_id_seq OWNED BY public.structureelements.id;


--
-- Name: structures; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.structures (
    id integer NOT NULL,
    "maxLevels" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.structures OWNER TO db;

--
-- Name: structures_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.structures_id_seq OWNER TO db;

--
-- Name: structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.structures_id_seq OWNED BY public.structures.id;


--
-- Name: systemmessages; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.systemmessages (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.systemmessages OWNER TO db;

--
-- Name: systemmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.systemmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.systemmessages_id_seq OWNER TO db;

--
-- Name: systemmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.systemmessages_id_seq OWNED BY public.systemmessages.id;


--
-- Name: taggroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.taggroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.taggroups OWNER TO db;

--
-- Name: taggroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.taggroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggroups_id_seq OWNER TO db;

--
-- Name: taggroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.taggroups_id_seq OWNED BY public.taggroups.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.tags OWNER TO db;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.tokens (
    id integer NOT NULL,
    token character(32) NOT NULL,
    route text,
    "usageLimit" smallint,
    "usageCount" smallint,
    "expiryDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.tokens OWNER TO db;

--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tokens_id_seq OWNER TO db;

--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: usergroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.usergroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.usergroups OWNER TO db;

--
-- Name: usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usergroups_id_seq OWNER TO db;

--
-- Name: usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.usergroups_id_seq OWNED BY public.usergroups.id;


--
-- Name: usergroups_users; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.usergroups_users (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.usergroups_users OWNER TO db;

--
-- Name: usergroups_users_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.usergroups_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usergroups_users_id_seq OWNER TO db;

--
-- Name: usergroups_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.usergroups_users_id_seq OWNED BY public.usergroups_users.id;


--
-- Name: userpermissions; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.userpermissions (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.userpermissions OWNER TO db;

--
-- Name: userpermissions_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.userpermissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userpermissions_id_seq OWNER TO db;

--
-- Name: userpermissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.userpermissions_id_seq OWNED BY public.userpermissions.id;


--
-- Name: userpermissions_usergroups; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.userpermissions_usergroups (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "groupId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.userpermissions_usergroups OWNER TO db;

--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.userpermissions_usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userpermissions_usergroups_id_seq OWNER TO db;

--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.userpermissions_usergroups_id_seq OWNED BY public.userpermissions_usergroups.id;


--
-- Name: userpermissions_users; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.userpermissions_users (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.userpermissions_users OWNER TO db;

--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.userpermissions_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userpermissions_users_id_seq OWNER TO db;

--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.userpermissions_users_id_seq OWNED BY public.userpermissions_users.id;


--
-- Name: userpreferences; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.userpreferences (
    "userId" integer NOT NULL,
    preferences text
);


ALTER TABLE public.userpreferences OWNER TO db;

--
-- Name: userpreferences_userId_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public."userpreferences_userId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."userpreferences_userId_seq" OWNER TO db;

--
-- Name: userpreferences_userId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public."userpreferences_userId_seq" OWNED BY public.userpreferences."userId";


--
-- Name: users; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.users (
    id integer NOT NULL,
    "photoId" integer,
    active boolean DEFAULT false NOT NULL,
    pending boolean DEFAULT false NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    suspended boolean DEFAULT false NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    username character varying(255),
    "fullName" character varying(255),
    "firstName" character varying(255),
    "lastName" character varying(255),
    email character varying(255),
    password character varying(255),
    "lastLoginDate" timestamp(0) without time zone,
    "lastLoginAttemptIp" character varying(45),
    "invalidLoginWindowStart" timestamp(0) without time zone,
    "invalidLoginCount" smallint,
    "lastInvalidLoginDate" timestamp(0) without time zone,
    "lockoutDate" timestamp(0) without time zone,
    "hasDashboard" boolean DEFAULT false NOT NULL,
    "verificationCode" character varying(255),
    "verificationCodeIssuedDate" timestamp(0) without time zone,
    "unverifiedEmail" character varying(255),
    "passwordResetRequired" boolean DEFAULT false NOT NULL,
    "lastPasswordChangeDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO db;

--
-- Name: volumefolders; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.volumefolders (
    id integer NOT NULL,
    "parentId" integer,
    "volumeId" integer,
    name character varying(255) NOT NULL,
    path character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.volumefolders OWNER TO db;

--
-- Name: volumefolders_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.volumefolders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.volumefolders_id_seq OWNER TO db;

--
-- Name: volumefolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.volumefolders_id_seq OWNED BY public.volumefolders.id;


--
-- Name: volumes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.volumes (
    id integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    fs character varying(255) NOT NULL,
    "transformFs" character varying(255),
    "transformSubpath" character varying(255),
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.volumes OWNER TO db;

--
-- Name: volumes_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.volumes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.volumes_id_seq OWNER TO db;

--
-- Name: volumes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.volumes_id_seq OWNED BY public.volumes.id;


--
-- Name: widgets; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.widgets (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    type character varying(255) NOT NULL,
    "sortOrder" smallint,
    colspan smallint,
    settings text,
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


ALTER TABLE public.widgets OWNER TO db;

--
-- Name: widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.widgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.widgets_id_seq OWNER TO db;

--
-- Name: widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.widgets_id_seq OWNED BY public.widgets.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: assetindexdata id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexdata ALTER COLUMN id SET DEFAULT nextval('public.assetindexdata_id_seq'::regclass);


--
-- Name: assetindexingsessions id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexingsessions ALTER COLUMN id SET DEFAULT nextval('public.assetindexingsessions_id_seq'::regclass);


--
-- Name: categorygroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_id_seq'::regclass);


--
-- Name: categorygroups_sites id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups_sites ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_sites_id_seq'::regclass);


--
-- Name: content id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content ALTER COLUMN id SET DEFAULT nextval('public.content_id_seq'::regclass);


--
-- Name: craftidtokens id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.craftidtokens ALTER COLUMN id SET DEFAULT nextval('public.craftidtokens_id_seq'::regclass);


--
-- Name: deprecationerrors id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.deprecationerrors ALTER COLUMN id SET DEFAULT nextval('public.deprecationerrors_id_seq'::regclass);


--
-- Name: drafts id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.drafts ALTER COLUMN id SET DEFAULT nextval('public.drafts_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: elements_sites id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements_sites ALTER COLUMN id SET DEFAULT nextval('public.elements_sites_id_seq'::regclass);


--
-- Name: entrytypes id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entrytypes ALTER COLUMN id SET DEFAULT nextval('public.entrytypes_id_seq'::regclass);


--
-- Name: fieldgroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldgroups ALTER COLUMN id SET DEFAULT nextval('public.fieldgroups_id_seq'::regclass);


--
-- Name: fieldlayoutfields id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayoutfields ALTER COLUMN id SET DEFAULT nextval('public.fieldlayoutfields_id_seq'::regclass);


--
-- Name: fieldlayouts id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayouts ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouts_id_seq'::regclass);


--
-- Name: fieldlayouttabs id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayouttabs ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouttabs_id_seq'::regclass);


--
-- Name: fields id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fields ALTER COLUMN id SET DEFAULT nextval('public.fields_id_seq'::regclass);


--
-- Name: globalsets id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.globalsets ALTER COLUMN id SET DEFAULT nextval('public.globalsets_id_seq'::regclass);


--
-- Name: gqlschemas id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.gqlschemas ALTER COLUMN id SET DEFAULT nextval('public.gqlschemas_id_seq'::regclass);


--
-- Name: gqltokens id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.gqltokens ALTER COLUMN id SET DEFAULT nextval('public.gqltokens_id_seq'::regclass);


--
-- Name: imagetransformindex id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.imagetransformindex ALTER COLUMN id SET DEFAULT nextval('public.imagetransformindex_id_seq'::regclass);


--
-- Name: imagetransforms id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.imagetransforms ALTER COLUMN id SET DEFAULT nextval('public.imagetransforms_id_seq'::regclass);


--
-- Name: info id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.info ALTER COLUMN id SET DEFAULT nextval('public.info_id_seq'::regclass);


--
-- Name: matrixblocktypes id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocktypes ALTER COLUMN id SET DEFAULT nextval('public.matrixblocktypes_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: plugins id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.plugins ALTER COLUMN id SET DEFAULT nextval('public.plugins_id_seq'::regclass);


--
-- Name: queue id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.queue ALTER COLUMN id SET DEFAULT nextval('public.queue_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: revisions id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.revisions ALTER COLUMN id SET DEFAULT nextval('public.revisions_id_seq'::regclass);


--
-- Name: sections id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections ALTER COLUMN id SET DEFAULT nextval('public.sections_id_seq'::regclass);


--
-- Name: sections_sites id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections_sites ALTER COLUMN id SET DEFAULT nextval('public.sections_sites_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: shunnedmessages id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.shunnedmessages ALTER COLUMN id SET DEFAULT nextval('public.shunnedmessages_id_seq'::regclass);


--
-- Name: sitegroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sitegroups ALTER COLUMN id SET DEFAULT nextval('public.sitegroups_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: structureelements id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structureelements ALTER COLUMN id SET DEFAULT nextval('public.structureelements_id_seq'::regclass);


--
-- Name: structures id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structures ALTER COLUMN id SET DEFAULT nextval('public.structures_id_seq'::regclass);


--
-- Name: systemmessages id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.systemmessages ALTER COLUMN id SET DEFAULT nextval('public.systemmessages_id_seq'::regclass);


--
-- Name: taggroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.taggroups ALTER COLUMN id SET DEFAULT nextval('public.taggroups_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: usergroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups ALTER COLUMN id SET DEFAULT nextval('public.usergroups_id_seq'::regclass);


--
-- Name: usergroups_users id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups_users ALTER COLUMN id SET DEFAULT nextval('public.usergroups_users_id_seq'::regclass);


--
-- Name: userpermissions id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_id_seq'::regclass);


--
-- Name: userpermissions_usergroups id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_usergroups ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_usergroups_id_seq'::regclass);


--
-- Name: userpermissions_users id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_users ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_users_id_seq'::regclass);


--
-- Name: userpreferences userId; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpreferences ALTER COLUMN "userId" SET DEFAULT nextval('public."userpreferences_userId_seq"'::regclass);


--
-- Name: volumefolders id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumefolders ALTER COLUMN id SET DEFAULT nextval('public.volumefolders_id_seq'::regclass);


--
-- Name: volumes id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumes ALTER COLUMN id SET DEFAULT nextval('public.volumes_id_seq'::regclass);


--
-- Name: widgets id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.widgets ALTER COLUMN id SET DEFAULT nextval('public.widgets_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.addresses (id, "ownerId", "countryCode", "administrativeArea", locality, "dependentLocality", "postalCode", "sortingCode", "addressLine1", "addressLine2", organization, "organizationTaxId", "fullName", "firstName", "lastName", latitude, longitude, "dateCreated", "dateUpdated") FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.announcements (id, "userId", "pluginId", heading, body, unread, "dateRead", "dateCreated") FROM stdin;
\.


--
-- Data for Name: assetindexdata; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.assetindexdata (id, "sessionId", "volumeId", uri, size, "timestamp", "isDir", "recordId", "isSkipped", "inProgress", completed, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: assetindexingsessions; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.assetindexingsessions (id, "indexedVolumes", "totalEntries", "processedEntries", "cacheRemoteImages", "isCli", "actionRequired", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, alt, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.categories (id, "groupId", "parentId", "deletedWithGroup", "dateCreated", "dateUpdated") FROM stdin;
\.


--
-- Data for Name: categorygroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.categorygroups (id, "structureId", "fieldLayoutId", name, handle, "defaultPlacement", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
\.


--
-- Data for Name: categorygroups_sites; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.categorygroups_sites (id, "groupId", "siteId", "hasUrls", "uriFormat", template, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: changedattributes; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") FROM stdin;
2	1	uri	2022-08-12 07:05:49	f	1
2	1	postDate	2022-08-12 07:05:51	f	1
1	1	email	2022-08-12 07:15:48	f	1
1	1	username	2022-08-12 07:16:55	f	1
1	1	password	2022-08-12 07:16:55	f	1
1	1	lastPasswordChangeDate	2022-08-12 07:16:55	f	1
1	1	fullName	2022-08-12 07:17:11	f	1
1	1	firstName	2022-08-12 07:17:11	f	1
1	1	lastName	2022-08-12 07:17:11	f	1
1	1	passwordResetRequired	2022-08-12 07:37:20	f	1
2	1	title	2022-08-12 07:52:19	f	1
2	1	slug	2022-08-12 07:52:19	f	1
6	1	slug	2022-08-12 07:52:27	f	1
6	1	uri	2022-08-12 07:52:27	f	1
6	1	title	2022-08-12 07:52:27	f	1
6	1	postDate	2022-08-12 07:52:28	f	1
\.


--
-- Data for Name: changedfields; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") FROM stdin;
2	1	1	2022-08-12 07:52:19	f	1
6	1	1	2022-08-12 07:52:27	f	1
\.


--
-- Data for Name: content; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_testField_uuqdrllc") FROM stdin;
3	3	1	Test	2022-08-12 07:05:51	2022-08-12 07:05:51	be9e1adb-28d8-4ba4-8a96-5830364c65e6	\N
1	1	1	\N	2022-08-05 08:36:00	2022-08-12 07:37:20	71c439bb-689b-4d36-8cfb-62f6feb91d5f	\N
2	2	1	First	2022-08-12 07:05:46	2022-08-12 07:52:19	c301453b-f0d9-441d-9f62-124628d7a234	Some Sample Text
5	5	1	First	2022-08-12 07:52:19	2022-08-12 07:52:19	1ba9bc98-b16a-4a5f-ae9f-bc5c4572b076	Some Sample Text
6	6	1	Second	2022-08-12 07:52:22	2022-08-12 07:52:28	ccf313c1-199d-4ec3-8500-28d31116dc3c	Second yeh!
7	7	1	Second	2022-08-12 07:52:28	2022-08-12 07:52:28	f92dae04-ec8c-47f4-a2a7-e9c83ef78d61	Second yeh!
\.


--
-- Data for Name: craftidtokens; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.craftidtokens (id, "userId", "accessToken", "expiryDate", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: deprecationerrors; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.deprecationerrors (id, key, fingerprint, "lastOccurrence", file, line, message, traces, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.drafts (id, "canonicalId", "creatorId", provisional, name, notes, "trackChanges", "dateLastMerged", saved) FROM stdin;
\.


--
-- Data for Name: elements; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) FROM stdin;
3	2	\N	1	2	craft\\elements\\Entry	t	f	2022-08-12 07:05:51	2022-08-12 07:05:51	\N	\N	f2269362-ca25-46c1-82a2-fe7ec56e141f
1	\N	\N	\N	\N	craft\\elements\\User	t	f	2022-08-05 08:36:00	2022-08-12 07:37:20	\N	\N	b2c82d23-b1e1-4da5-8b33-caedd784b99c
2	\N	\N	\N	2	craft\\elements\\Entry	t	f	2022-08-12 07:05:46	2022-08-12 07:52:19	\N	\N	3958c874-6f9d-43f7-90ff-3079fc5c5b3d
5	2	\N	2	2	craft\\elements\\Entry	t	f	2022-08-12 07:52:19	2022-08-12 07:52:19	\N	\N	25b18549-77c9-475a-80b1-6b83727652ae
6	\N	\N	\N	2	craft\\elements\\Entry	t	f	2022-08-12 07:52:22	2022-08-12 07:52:28	\N	\N	7104bfb5-86bc-4efd-bc77-ab9428486334
7	6	\N	3	2	craft\\elements\\Entry	t	f	2022-08-12 07:52:28	2022-08-12 07:52:28	\N	\N	d53db5d4-2fb1-44ed-8ffa-a737faf39971
\.


--
-- Data for Name: elements_sites; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) FROM stdin;
1	1	1	\N	\N	t	2022-08-05 08:36:00	2022-08-05 08:36:00	5f6e1f00-225a-4286-b442-1d2d482bf07a
3	3	1	test	test/test	t	2022-08-12 07:05:51	2022-08-12 07:05:51	00017673-f944-4a47-9c9b-1bdd313cf706
2	2	1	first	test/first	t	2022-08-12 07:05:46	2022-08-12 07:52:19	c24edaeb-276d-4d54-a184-ff09ce2e3342
5	5	1	first	test/first	t	2022-08-12 07:52:19	2022-08-12 07:52:19	bb0fa0ec-bf4e-406f-80de-9b4496a1a939
6	6	1	second	test/second	t	2022-08-12 07:52:22	2022-08-12 07:52:27	e9a58150-b2d5-459c-8603-5de0e6845301
7	7	1	second	test/second	t	2022-08-12 07:52:28	2022-08-12 07:52:28	be54649b-a6e2-40fd-92de-a20b7b28d78c
\.


--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated") FROM stdin;
2	1	\N	1	1	2022-08-12 07:05:00	\N	\N	2022-08-12 07:05:46	2022-08-12 07:05:51
3	1	\N	1	1	2022-08-12 07:05:00	\N	\N	2022-08-12 07:05:51	2022-08-12 07:05:51
5	1	\N	1	1	2022-08-12 07:05:00	\N	\N	2022-08-12 07:52:19	2022-08-12 07:52:19
6	1	\N	1	1	2022-08-12 07:52:00	\N	\N	2022-08-12 07:52:22	2022-08-12 07:52:28
7	1	\N	1	1	2022-08-12 07:52:00	\N	\N	2022-08-12 07:52:28	2022-08-12 07:52:28
\.


--
-- Data for Name: entrytypes; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	1	2	Default	default	t	site	\N	\N	1	2022-08-12 07:05:34	2022-08-12 07:05:34	\N	56e79093-cee3-497c-8357-fafdfefc403b
\.


--
-- Data for Name: fieldgroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.fieldgroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	Common	2022-08-05 08:36:00	2022-08-05 08:36:00	\N	12be32af-0827-4977-8ffb-bd1249cef734
\.


--
-- Data for Name: fieldlayoutfields; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) FROM stdin;
1	2	6	1	f	1	2022-08-12 07:51:57	2022-08-12 07:51:57	18eb30a9-a184-4740-a9bb-7a8984c262a9
\.


--
-- Data for Name: fieldlayouts; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	craft\\elements\\Asset	2022-08-12 07:02:32	2022-08-12 07:02:32	\N	3792e5e7-16ed-417d-b432-e6db7e73a942
2	craft\\elements\\Entry	2022-08-12 07:05:34	2022-08-12 07:05:34	\N	d1b303dc-1f27-4ade-8950-a6c0b5a72cc7
\.


--
-- Data for Name: fieldlayouttabs; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.fieldlayouttabs (id, "layoutId", name, settings, elements, "sortOrder", "dateCreated", "dateUpdated", uid) FROM stdin;
4	1	Content	{"userCondition":null,"elementCondition":null}	[{"type":"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100,"uid":"e7194ca2-4740-4ad4-a967-bd4317b707da","userCondition":null,"elementCondition":null},{"type":"craft\\\\fieldlayoutelements\\\\assets\\\\AltField","attribute":"alt","requirable":true,"class":null,"rows":null,"cols":null,"name":null,"disabled":false,"readonly":false,"title":null,"placeholder":null,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"uid":"9b6da8d2-cc48-498b-a89a-d4566f243671","userCondition":null,"elementCondition":null}]	1	2022-08-12 07:02:32	2022-08-12 07:02:32	030ddba9-dc9b-44af-bd4a-4ba13a42422b
6	2	Content	{"userCondition":null,"elementCondition":null}	[{"type":"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100,"uid":"00fcd017-4b37-4566-8ac4-d1125130d3d6","userCondition":null,"elementCondition":null},{"type":"craft\\\\fieldlayoutelements\\\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"uid":"6b70f7a0-f984-4a13-8be6-544cb16928df","userCondition":null,"elementCondition":null,"fieldUid":"2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39"}]	1	2022-08-12 07:51:57	2022-08-12 07:51:57	b6868509-fff0-4e6d-b50d-8a93e24ec183
\.


--
-- Data for Name: fields; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.fields (id, "groupId", name, handle, context, "columnSuffix", instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) FROM stdin;
1	1	Test Field	testField	global	uuqdrllc	Test Element	f	none	\N	craft\\fields\\PlainText	{"byteLimit":null,"charLimit":null,"code":false,"columnType":null,"initialRows":4,"multiline":true,"placeholder":"Enter Some Text","uiMode":"normal"}	2022-08-12 07:05:05	2022-08-12 07:53:43	2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39
\.


--
-- Data for Name: globalsets; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.globalsets (id, name, handle, "fieldLayoutId", "sortOrder", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: gqlschemas; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.gqlschemas (id, name, scope, "isPublic", "dateCreated", "dateUpdated", uid) FROM stdin;
1	Public Schema	["sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e:read","sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b:read","entrytypes.56e79093-cee3-497c-8357-fafdfefc403b:read","volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848:read"]	t	2022-08-12 07:03:25	2022-08-12 07:48:26	03e236c5-1d8b-4a59-95ad-1a8b206dcbbf
\.


--
-- Data for Name: gqltokens; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.gqltokens (id, name, "accessToken", enabled, "expiryDate", "lastUsed", "schemaId", "dateCreated", "dateUpdated", uid) FROM stdin;
1	Public Token	__PUBLIC__	t	\N	2022-08-12 10:02:08	\N	2022-08-12 07:03:54	2022-08-12 10:02:08	6080b7f2-6271-4577-b8e6-5d5101ec5f42
\.


--
-- Data for Name: imagetransformindex; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.imagetransformindex (id, "assetId", transformer, filename, format, "transformString", "fileExists", "inProgress", error, "dateIndexed", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: imagetransforms; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.imagetransforms (id, name, handle, mode, "position", width, height, format, quality, interlace, "parameterChangeTime", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: info; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.info (id, version, "schemaVersion", maintenance, "configVersion", "fieldVersion", "dateCreated", "dateUpdated", uid) FROM stdin;
1	4.2.1.1	4.0.0.9	f	bqoavfenitug	3@xvdldrqood	2022-08-05 08:36:00	2022-08-12 07:53:43	2cefeb03-b47f-4bea-82e5-77f7213c8eb4
\.


--
-- Data for Name: matrixblocks; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.matrixblocks (id, "primaryOwnerId", "fieldId", "typeId", "deletedWithOwner", "dateCreated", "dateUpdated") FROM stdin;
\.


--
-- Data for Name: matrixblocks_owners; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.matrixblocks_owners ("blockId", "ownerId", "sortOrder") FROM stdin;
\.


--
-- Data for Name: matrixblocktypes; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.matrixblocktypes (id, "fieldId", "fieldLayoutId", name, handle, "sortOrder", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) FROM stdin;
1	craft	Install	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	63436cf0-5b04-4743-b8f1-fc0fc67812e5
2	craft	m210121_145800_asset_indexing_changes	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	d148936c-c6d6-487c-912d-167724b6dcdb
3	craft	m210624_222934_drop_deprecated_tables	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	d9c74518-d889-4446-922f-fe27923b0a4a
4	craft	m210724_180756_rename_source_cols	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	94c9f47e-da5e-4b89-aad4-255847fa62ec
5	craft	m210809_124211_remove_superfluous_uids	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	0eb4c4df-5ecc-4513-8e1f-8a2475602c76
6	craft	m210817_014201_universal_users	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	430b0787-abbb-46f0-a2b3-7b571197a3f2
7	craft	m210904_132612_store_element_source_settings_in_project_config	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	f110a254-0479-4b31-8556-2d4937f26f03
8	craft	m211115_135500_image_transformers	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	37a5df07-6e09-4496-858b-dc63c7f797d6
9	craft	m211201_131000_filesystems	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	49aa34ee-2b27-402a-aff6-fef593cfde3d
10	craft	m220103_043103_tab_conditions	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	23d29ce6-60f5-4db4-b2c9-4520781e5861
11	craft	m220104_003433_asset_alt_text	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	888c03ca-2b40-46ac-889c-fa99b266f231
12	craft	m220123_213619_update_permissions	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	f16b28e1-8dd0-4d8f-8dfd-cb8cf97cef5f
13	craft	m220126_003432_addresses	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	5d2010fc-b031-42b0-bafa-9f10a31b6694
14	craft	m220209_095604_add_indexes	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	a7b0b501-30cf-4f27-ba9b-3f430fb1c5e9
15	craft	m220213_015220_matrixblocks_owners_table	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	1d4112eb-71de-4f78-ab4e-ca095eaaf0e5
16	craft	m220214_000000_truncate_sessions	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	27d0d585-a066-4316-8ad2-faed119430d0
17	craft	m220222_122159_full_names	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	366a11e3-7edc-43c7-bf63-5594823cdb7e
18	craft	m220223_180559_nullable_address_owner	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	9fc1a63b-9351-4e9d-aba8-17e671a5479c
19	craft	m220225_165000_transform_filesystems	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	c4c7fed0-8074-4b0b-af92-f4171305fdc8
20	craft	m220309_152006_rename_field_layout_elements	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	20fe932d-6f44-481f-9893-80f8d7b71c2b
21	craft	m220314_211928_field_layout_element_uids	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	fa4f295b-3ef2-4a82-9a7f-2059c1832870
22	craft	m220316_123800_transform_fs_subpath	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	15cdfaf8-d2a4-4579-a1f3-8f1cff29dfb7
23	craft	m220317_174250_release_all_jobs	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	623ad002-4bdd-4bf9-9c47-bf2078a2dd1e
24	craft	m220330_150000_add_site_gql_schema_components	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	310b9550-9909-4094-92dc-61145e977247
25	craft	m220413_024536_site_enabled_string	2022-08-05 08:36:01	2022-08-05 08:36:01	2022-08-05 08:36:01	ff6a33a3-bc19-4234-998e-9b3dd6acf563
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: projectconfig; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.projectconfig (path, value) FROM stdin;
fieldGroups.12be32af-0827-4977-8ffb-bd1249cef734.name	"Common"
siteGroups.82055621-ce0c-4ef9-881e-9f7d05410b1a.name	"DUET Property Group"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.baseUrl	"$PRIMARY_SITE_URL"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.handle	"default"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.hasUrls	true
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.language	"en-AU"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.name	"DUET Property Group"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.primary	true
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.siteGroup	"82055621-ce0c-4ef9-881e-9f7d05410b1a"
sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.sortOrder	1
graphql.publicToken.enabled	true
graphql.publicToken.expiryDate	null
users.requireEmailVerification	true
users.allowPublicRegistration	false
users.defaultGroup	null
users.photoVolumeUid	null
users.photoSubpath	null
meta.__names__.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e	"DUET Property Group"
meta.__names__.12be32af-0827-4977-8ffb-bd1249cef734	"Common"
meta.__names__.6376c7c3-7034-4df5-b461-b3b8a7c85848	"Images"
meta.__names__.82055621-ce0c-4ef9-881e-9f7d05410b1a	"DUET Property Group"
fs.assets.hasUrls	true
fs.assets.name	"assets"
fs.assets.settings.path	"$ASSETS"
fs.assets.type	"craft\\\\fs\\\\Local"
fs.assets.url	"$ASSETS_URL"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elementCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.attribute	"alt"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.class	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.cols	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.disabled	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.elementCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.id	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.instructions	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.label	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.name	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.orientation	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.placeholder	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.readonly	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.requirable	true
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.required	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.rows	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.tip	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.title	null
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.defaultPlacement	"end"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.enableVersioning	true
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.handle	"test"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.name	"Test"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.0.0	"label"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.0.1	"Primary entry page"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.1.0	"urlFormat"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.1.1	"{url}"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.2.0	"refresh"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.previewTargets.0.__assoc__.2.1	"1"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.propagationMethod	"all"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.siteSettings.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.enabledByDefault	true
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.siteSettings.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.hasUrls	true
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.siteSettings.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.template	"test/_entry"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.siteSettings.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e.uriFormat	"test/{slug}"
sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b.type	"channel"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.type	"craft\\\\fieldlayoutelements\\\\assets\\\\AltField"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.uid	"9b6da8d2-cc48-498b-a89a-d4566f243671"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.userCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.warning	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.1.width	100
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.name	"Content"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.uid	"030ddba9-dc9b-44af-bd4a-4ba13a42422b"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.userCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fs	"assets"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.handle	"images"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.name	"Images"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.sortOrder	1
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.titleTranslationKeyFormat	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.titleTranslationMethod	"site"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.transformFs	""
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.transformSubpath	"images"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.autocapitalize	true
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.autocomplete	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.autocorrect	true
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.class	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.disabled	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.elementCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.id	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.instructions	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.label	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.max	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.min	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.name	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.orientation	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.placeholder	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.readonly	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.requirable	false
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.size	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.step	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.tip	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.title	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.type	"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.uid	"e7194ca2-4740-4ad4-a967-bd4317b707da"
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.userCondition	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.warning	null
volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848.fieldLayouts.3792e5e7-16ed-417d-b432-e6db7e73a942.tabs.0.elements.0.width	100
system.edition	"pro"
system.live	true
system.name	"$CRAFT_NAME"
system.retryDuration	null
system.schemaVersion	"4.0.0.9"
system.timeZone	"$CRAFT_TZ"
meta.__names__.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf	"Public Schema"
meta.__names__.41b2ce81-f11d-4b1f-a788-e365a71b3b8b	"Test"
meta.__names__.56e79093-cee3-497c-8357-fafdfefc403b	"Default"
email.fromEmail	"$MAIL_SYSTEM_EMAIL"
email.fromName	"$MAIL_SENDER_NAME"
email.replyToEmail	"$MAIL_SYSTEM_REPLY"
email.template	""
email.transportSettings.encryptionMethod	"$MAIL_ENCRYPTION"
email.transportSettings.host	"$MAIL_HOST"
email.transportSettings.password	""
email.transportSettings.port	"$MAIL_PORT"
email.transportSettings.timeout	"10"
email.transportSettings.useAuthentication	"$MAIL_AUTH"
email.transportSettings.username	""
email.transportType	"craft\\\\mail\\\\transportadapters\\\\Smtp"
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.isPublic	true
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.name	"Public Schema"
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.scope.0	"sites.6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e:read"
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.scope.1	"sections.41b2ce81-f11d-4b1f-a788-e365a71b3b8b:read"
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.scope.2	"entrytypes.56e79093-cee3-497c-8357-fafdfefc403b:read"
graphql.schemas.03e236c5-1d8b-4a59-95ad-1a8b206dcbbf.scope.3	"volumes.6376c7c3-7034-4df5-b461-b3b8a7c85848:read"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elementCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.autocapitalize	true
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.autocomplete	false
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.autocorrect	true
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.class	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.disabled	false
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.elementCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.id	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.instructions	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.label	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.max	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.min	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.name	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.orientation	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.placeholder	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.readonly	false
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.requirable	false
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.size	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.step	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.tip	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.title	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.type	"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.uid	"00fcd017-4b37-4566-8ac4-d1125130d3d6"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.userCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.warning	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.0.width	100
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.elementCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.fieldUid	"2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.instructions	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.label	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.required	false
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.tip	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.type	"craft\\\\fieldlayoutelements\\\\CustomField"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.uid	"6b70f7a0-f984-4a13-8be6-544cb16928df"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.userCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.warning	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.elements.1.width	100
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.name	"Content"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.uid	"b6868509-fff0-4e6d-b50d-8a93e24ec183"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.fieldLayouts.d1b303dc-1f27-4ade-8950-a6c0b5a72cc7.tabs.0.userCondition	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.handle	"default"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.hasTitleField	true
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.name	"Default"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.section	"41b2ce81-f11d-4b1f-a788-e365a71b3b8b"
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.sortOrder	1
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.titleFormat	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.titleTranslationKeyFormat	null
entryTypes.56e79093-cee3-497c-8357-fafdfefc403b.titleTranslationMethod	"site"
dateModified	1660290822
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.columnSuffix	"uuqdrllc"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.contentColumnType	"text"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.fieldGroup	"12be32af-0827-4977-8ffb-bd1249cef734"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.handle	"testField"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.instructions	"Test Element"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.name	"Test Field"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.searchable	false
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.byteLimit	null
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.charLimit	null
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.code	false
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.columnType	null
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.initialRows	4
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.multiline	true
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.placeholder	"Enter Some Text"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.settings.uiMode	"normal"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.translationKeyFormat	null
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.translationMethod	"none"
fields.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39.type	"craft\\\\fields\\\\PlainText"
meta.__names__.2f591bc9-ab4c-45ef-b0f3-a1b87d5b0f39	"Test Field"
\.


--
-- Data for Name: queue; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.queue (id, channel, job, description, "timePushed", ttr, delay, priority, "dateReserved", "timeUpdated", progress, "progressLabel", attempt, fail, "dateFailed", error) FROM stdin;
\.


--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.relations (id, "fieldId", "sourceId", "sourceSiteId", "targetId", "sortOrder", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: resourcepaths; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.resourcepaths (hash, path) FROM stdin;
dc6404cf	@craft/web/assets/feed/dist
9f4c478d	@craft/web/assets/prismjs/dist
73a4cbb3	@craft/web/assets/updater/dist
c741537d	@craft/web/assets/vue/dist
57d8266e	@craft/web/assets/pluginstore/dist
4512ed9	@craft/web/assets/utilities/dist
4df29bd9	@craft/web/assets/generalsettings/dist
147bb8e7	@craft/web/assets/fabric/dist
4ff739ed	@craft/web/assets/iframeresizer/dist
7a678dec	@craft/web/assets/recententries/dist
c719a322	@craft/web/assets/editsection/dist
e371398b	@craft/web/assets/craftsupport/dist
44ddcf82	@craft/web/assets/updateswidget/dist
a5272204	@craft/web/assets/dashboard/dist
499eecdb	@craft/web/assets/fieldsettings/dist
be202177	@craft/web/assets/edituser/dist
244a15bc	@craft/web/assets/graphiql/dist
5ea31613	@craft/web/assets/cp/dist
55fe0e79	@craft/web/assets/tailwindreset/dist
629218b5	@craft/web/assets/axios/dist
4496305a	@craft/web/assets/d3/dist
85b83db1	@craft/web/assets/elementresizedetector/dist
5c58a588	@craft/web/assets/focusvisible/dist
3cc98ff0	@craft/web/assets/garnish/dist
80582259	@bower/jquery/dist
d6a556f3	@craft/web/assets/jquerytouchevents/dist
d3618b26	@craft/web/assets/velocity/dist
8abfb24f	@craft/web/assets/jqueryui/dist
d6f68991	@craft/web/assets/jquerypayment/dist
d8fd0056	@craft/web/assets/datepickeri18n/dist
eaad534f	@craft/web/assets/picturefill/dist
52ebb45b	@craft/web/assets/selectize/dist
94c464e4	@craft/web/assets/fileupload/dist
e115ee4f	@craft/web/assets/xregexp/dist
\.


--
-- Data for Name: revisions; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.revisions (id, "canonicalId", "creatorId", num, notes) FROM stdin;
1	2	1	1	
2	2	1	2	Applied “Draft 1”
3	6	1	1	
\.


--
-- Data for Name: searchindex; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) FROM stdin;
1	username	0	1	 wtadmin 	'wtadmin'
1	fullname	0	1	 wt administrator 	'administrator' 'wt'
1	firstname	0	1	 w 	'w'
1	lastname	0	1	 administrator 	'administrator'
1	email	0	1	 wt aus per techservices wundermanthompson com 	'aus' 'com' 'per' 'techservices' 'wt' 'wundermanthompson'
1	slug	0	1		
2	slug	0	1	 first 	'first'
2	title	0	1	 first 	'first'
6	slug	0	1	 second 	'second'
6	title	0	1	 second 	'second'
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	\N	Test	test	channel	t	all	end	[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]	2022-08-12 07:05:34	2022-08-12 07:05:34	\N	41b2ce81-f11d-4b1f-a788-e365a71b3b8b
\.


--
-- Data for Name: sections_sites; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) FROM stdin;
1	1	1	t	test/{slug}	test/_entry	t	2022-08-12 07:05:34	2022-08-12 07:05:34	0c732fb7-7d03-431c-9895-b3b70d0a1ecf
\.


--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sequences (name, next) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sessions (id, "userId", token, "dateCreated", "dateUpdated", uid) FROM stdin;
6	1	2mvVCVXQhBcyMURinvCi-0ylz7Z_h9u9EfUtdd48DlUGPRuBpPDKuPEAN_WfSFu5C-3SWMxaY_AZjaVeraxtN8oQyUjfql9xmWa2	2022-08-12 09:17:30	2022-08-12 10:03:29	4efc1527-40a7-43fd-8795-40e70c8dc36d
4	1	eCqluXAsPXwRfVE56gj2jGzgXg20aoVYrNNdT3LR8yj2PAdXOMH_G8au_36TICk47MUuYah8-XpEwGN8cmUDEHz3d8wFKa_JR0vt	2022-08-12 07:30:20	2022-08-12 08:16:29	c23805d6-afc9-46bc-8cb5-fce38d42eacb
5	1	ozAcaNQ0M4cj73syF3LEvbssZn_M7-WBpWBeMt4m9JgSmkcRdKNOElslAurlk4e9knaHUqxXESU8eGggGtTf94owvDZmWwxOB94L	2022-08-12 08:18:27	2022-08-12 09:15:24	c3908c22-52e5-4a27-9139-0aaaa3294371
3	1	luUS4ecU2aoLEFGLcHRvQRkEzfXhHxXoMLjHd6OYm0j3bYGmyuUTBotJxd5RP2tnGv6HjQNStJwOogXVIQBqpGAmzL_OHQZH13FS	2022-08-12 07:26:07	2022-08-12 09:17:30	27c1b4af-50db-489a-89fd-5a7abb2157df
\.


--
-- Data for Name: shunnedmessages; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.shunnedmessages (id, "userId", message, "expiryDate", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: sitegroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sitegroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	DUET Property Group	2022-08-05 08:36:00	2022-08-05 08:36:00	\N	82055621-ce0c-4ef9-881e-9f7d05410b1a
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.sites (id, "groupId", "primary", enabled, name, handle, language, "hasUrls", "baseUrl", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	1	t	true	DUET Property Group	default	en-AU	t	$PRIMARY_SITE_URL	1	2022-08-05 08:36:00	2022-08-05 08:36:00	\N	6b4c2e70-1542-4e82-b1a7-be0f0ad2ce7e
\.


--
-- Data for Name: structureelements; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.structureelements (id, "structureId", "elementId", root, lft, rgt, level, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: structures; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.structures (id, "maxLevels", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
\.


--
-- Data for Name: systemmessages; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.systemmessages (id, language, key, subject, body, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: taggroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.taggroups (id, name, handle, "fieldLayoutId", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.tags (id, "groupId", "deletedWithGroup", "dateCreated", "dateUpdated") FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.tokens (id, token, route, "usageLimit", "usageCount", "expiryDate", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: usergroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.usergroups (id, name, handle, description, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: usergroups_users; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.usergroups_users (id, "groupId", "userId", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: userpermissions; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.userpermissions (id, name, "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: userpermissions_usergroups; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.userpermissions_usergroups (id, "permissionId", "groupId", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: userpermissions_users; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.userpermissions_users (id, "permissionId", "userId", "dateCreated", "dateUpdated", uid) FROM stdin;
\.


--
-- Data for Name: userpreferences; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.userpreferences ("userId", preferences) FROM stdin;
1	{"language":"en-GB","locale":null,"weekStartDay":"1","alwaysShowFocusRings":false,"useShapes":false,"underlineLinks":false,"notificationDuration":"5000","showFieldHandles":false,"enableDebugToolbarForSite":false,"enableDebugToolbarForCp":false,"showExceptionView":false,"profileTemplates":false}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.users (id, "photoId", active, pending, locked, suspended, admin, username, "fullName", "firstName", "lastName", email, password, "lastLoginDate", "lastLoginAttemptIp", "invalidLoginWindowStart", "invalidLoginCount", "lastInvalidLoginDate", "lockoutDate", "hasDashboard", "verificationCode", "verificationCodeIssuedDate", "unverifiedEmail", "passwordResetRequired", "lastPasswordChangeDate", "dateCreated", "dateUpdated") FROM stdin;
1	\N	t	f	f	f	t	wtadmin	WT Administrator	W	Administrator	wt-aus-per-techservices@wundermanthompson.com	$2y$13$at591p7QZL13R4M2vHmPfuc49TNlTGXteFWnGPRtkGv0Q4FbGswOy	2022-08-12 09:17:30	\N	\N	\N	2022-08-12 07:03:47	\N	t	$2y$13$79oEMAIhP/7/RT9qIYFFZ.2MhkN1iHyDhlyZkQe3QWOocWdwpmrkC	2022-08-12 07:37:53	\N	t	2022-08-12 07:16:55	2022-08-05 08:36:01	2022-08-12 09:17:30
\.


--
-- Data for Name: volumefolders; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) FROM stdin;
1	\N	1	Images	\N	2022-08-12 07:02:32	2022-08-12 07:02:32	fb357512-a841-44d3-8479-e97d53da4834
\.


--
-- Data for Name: volumes; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.volumes (id, "fieldLayoutId", name, handle, fs, "transformFs", "transformSubpath", "titleTranslationMethod", "titleTranslationKeyFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) FROM stdin;
1	1	Images	images	assets		images	site	\N	1	2022-08-12 07:02:32	2022-08-12 07:02:32	\N	6376c7c3-7034-4df5-b461-b3b8a7c85848
\.


--
-- Data for Name: widgets; Type: TABLE DATA; Schema: public; Owner: db
--

COPY public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) FROM stdin;
1	1	craft\\widgets\\RecentEntries	1	\N	{"siteId":1,"section":"*","limit":10}	t	2022-08-12 07:02:17	2022-08-12 07:02:17	d182d56e-5baf-445a-8ec0-1292a6b455f1
2	1	craft\\widgets\\CraftSupport	2	\N	[]	t	2022-08-12 07:02:17	2022-08-12 07:02:17	f6c69434-b8bb-44d0-b317-925bd6816d8b
3	1	craft\\widgets\\Updates	3	\N	[]	t	2022-08-12 07:02:17	2022-08-12 07:02:17	90c13359-f7e6-47ac-8234-7b7842ffc67d
4	1	craft\\widgets\\Feed	4	\N	{"url":"https://craftcms.com/news.rss","title":"Craft News","limit":5}	t	2022-08-12 07:02:17	2022-08-12 07:02:17	7f6f9bd0-f4b7-4f16-8e8f-9e5af13e5f56
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.assetindexdata_id_seq', 1, false);


--
-- Name: assetindexingsessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.assetindexingsessions_id_seq', 1, false);


--
-- Name: categorygroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.categorygroups_id_seq', 1, false);


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.categorygroups_sites_id_seq', 1, false);


--
-- Name: content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.content_id_seq', 7, true);


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.craftidtokens_id_seq', 1, false);


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.deprecationerrors_id_seq', 1, false);


--
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.drafts_id_seq', 3, true);


--
-- Name: elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.elements_id_seq', 7, true);


--
-- Name: elements_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.elements_sites_id_seq', 7, true);


--
-- Name: entrytypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.entrytypes_id_seq', 1, true);


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.fieldgroups_id_seq', 1, true);


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.fieldlayoutfields_id_seq', 1, true);


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.fieldlayouts_id_seq', 2, true);


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.fieldlayouttabs_id_seq', 6, true);


--
-- Name: fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.fields_id_seq', 1, true);


--
-- Name: globalsets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.globalsets_id_seq', 1, false);


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.gqlschemas_id_seq', 1, true);


--
-- Name: gqltokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.gqltokens_id_seq', 1, true);


--
-- Name: imagetransformindex_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.imagetransformindex_id_seq', 1, false);


--
-- Name: imagetransforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.imagetransforms_id_seq', 1, false);


--
-- Name: info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.info_id_seq', 1, false);


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.matrixblocktypes_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.migrations_id_seq', 25, true);


--
-- Name: plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.plugins_id_seq', 1, false);


--
-- Name: queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.queue_id_seq', 23, true);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.relations_id_seq', 1, false);


--
-- Name: revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.revisions_id_seq', 3, true);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.sections_id_seq', 1, true);


--
-- Name: sections_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.sections_sites_id_seq', 1, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.sessions_id_seq', 6, true);


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.shunnedmessages_id_seq', 1, false);


--
-- Name: sitegroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.sitegroups_id_seq', 1, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.sites_id_seq', 1, true);


--
-- Name: structureelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.structureelements_id_seq', 1, false);


--
-- Name: structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.structures_id_seq', 1, false);


--
-- Name: systemmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.systemmessages_id_seq', 1, false);


--
-- Name: taggroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.taggroups_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.tokens_id_seq', 1, false);


--
-- Name: usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.usergroups_id_seq', 1, false);


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.usergroups_users_id_seq', 1, false);


--
-- Name: userpermissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.userpermissions_id_seq', 1, false);


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.userpermissions_usergroups_id_seq', 1, false);


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.userpermissions_users_id_seq', 1, false);


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public."userpreferences_userId_seq"', 1, false);


--
-- Name: volumefolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.volumefolders_id_seq', 1, true);


--
-- Name: volumes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.volumes_id_seq', 1, true);


--
-- Name: widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.widgets_id_seq', 4, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: assetindexdata assetindexdata_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT assetindexdata_pkey PRIMARY KEY (id);


--
-- Name: assetindexingsessions assetindexingsessions_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexingsessions
    ADD CONSTRAINT assetindexingsessions_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categorygroups categorygroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT categorygroups_pkey PRIMARY KEY (id);


--
-- Name: categorygroups_sites categorygroups_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT categorygroups_sites_pkey PRIMARY KEY (id);


--
-- Name: changedattributes changedattributes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT changedattributes_pkey PRIMARY KEY ("elementId", "siteId", attribute);


--
-- Name: changedfields changedfields_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT changedfields_pkey PRIMARY KEY ("elementId", "siteId", "fieldId");


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: craftidtokens craftidtokens_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT craftidtokens_pkey PRIMARY KEY (id);


--
-- Name: deprecationerrors deprecationerrors_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.deprecationerrors
    ADD CONSTRAINT deprecationerrors_pkey PRIMARY KEY (id);


--
-- Name: drafts drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: elements_sites elements_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT elements_sites_pkey PRIMARY KEY (id);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: entrytypes entrytypes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT entrytypes_pkey PRIMARY KEY (id);


--
-- Name: fieldgroups fieldgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldgroups
    ADD CONSTRAINT fieldgroups_pkey PRIMARY KEY (id);


--
-- Name: fieldlayoutfields fieldlayoutfields_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fieldlayoutfields_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouts fieldlayouts_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayouts
    ADD CONSTRAINT fieldlayouts_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouttabs fieldlayouttabs_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fieldlayouttabs_pkey PRIMARY KEY (id);


--
-- Name: fields fields_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fields_pkey PRIMARY KEY (id);


--
-- Name: globalsets globalsets_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT globalsets_pkey PRIMARY KEY (id);


--
-- Name: gqlschemas gqlschemas_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.gqlschemas
    ADD CONSTRAINT gqlschemas_pkey PRIMARY KEY (id);


--
-- Name: gqltokens gqltokens_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT gqltokens_pkey PRIMARY KEY (id);


--
-- Name: imagetransformindex imagetransformindex_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.imagetransformindex
    ADD CONSTRAINT imagetransformindex_pkey PRIMARY KEY (id);


--
-- Name: imagetransforms imagetransforms_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.imagetransforms
    ADD CONSTRAINT imagetransforms_pkey PRIMARY KEY (id);


--
-- Name: info info_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.info
    ADD CONSTRAINT info_pkey PRIMARY KEY (id);


--
-- Name: matrixblocks_owners matrixblocks_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks_owners
    ADD CONSTRAINT matrixblocks_owners_pkey PRIMARY KEY ("blockId", "ownerId");


--
-- Name: matrixblocks matrixblocks_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT matrixblocks_pkey PRIMARY KEY (id);


--
-- Name: matrixblocktypes matrixblocktypes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT matrixblocktypes_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: searchindex pk_emuudqkbopitopymzjmrcuobvsqwbfjhesyu; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.searchindex
    ADD CONSTRAINT pk_emuudqkbopitopymzjmrcuobvsqwbfjhesyu PRIMARY KEY ("elementId", attribute, "fieldId", "siteId");


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: projectconfig projectconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.projectconfig
    ADD CONSTRAINT projectconfig_pkey PRIMARY KEY (path);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: resourcepaths resourcepaths_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.resourcepaths
    ADD CONSTRAINT resourcepaths_pkey PRIMARY KEY (hash);


--
-- Name: revisions revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT revisions_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: sections_sites sections_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT sections_sites_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY (name);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shunnedmessages shunnedmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT shunnedmessages_pkey PRIMARY KEY (id);


--
-- Name: sitegroups sitegroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sitegroups
    ADD CONSTRAINT sitegroups_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: structureelements structureelements_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT structureelements_pkey PRIMARY KEY (id);


--
-- Name: structures structures_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structures
    ADD CONSTRAINT structures_pkey PRIMARY KEY (id);


--
-- Name: systemmessages systemmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.systemmessages
    ADD CONSTRAINT systemmessages_pkey PRIMARY KEY (id);


--
-- Name: taggroups taggroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT taggroups_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: usergroups usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups
    ADD CONSTRAINT usergroups_pkey PRIMARY KEY (id);


--
-- Name: usergroups_users usergroups_users_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT usergroups_users_pkey PRIMARY KEY (id);


--
-- Name: userpermissions userpermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions
    ADD CONSTRAINT userpermissions_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_usergroups userpermissions_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT userpermissions_usergroups_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_users userpermissions_users_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT userpermissions_users_pkey PRIMARY KEY (id);


--
-- Name: userpreferences userpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT userpreferences_pkey PRIMARY KEY ("userId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: volumefolders volumefolders_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT volumefolders_pkey PRIMARY KEY (id);


--
-- Name: volumes volumes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT volumes_pkey PRIMARY KEY (id);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (id);


--
-- Name: idx_aeyvuihkowzroxfuvdadxfskupszvisdahnt; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_aeyvuihkowzroxfuvdadxfskupszvisdahnt ON public.fieldlayouts USING btree ("dateDeleted");


--
-- Name: idx_apczdjarpwsoebtwakvrtnqrfctchrpzmvqw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_apczdjarpwsoebtwakvrtnqrfctchrpzmvqw ON public.matrixblocks USING btree ("typeId");


--
-- Name: idx_asfhkxmslwumqjvzfkswpsnuifougdktfmok; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_asfhkxmslwumqjvzfkswpsnuifougdktfmok ON public.tokens USING btree (token);


--
-- Name: idx_atzdiptsyymiraeryskrtcsnanvdsgumjawb; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_atzdiptsyymiraeryskrtcsnanvdsgumjawb ON public.systemmessages USING btree (key, language);


--
-- Name: idx_auxtpfjufzrxpufdkijepwpwupdsddjdbpst; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_auxtpfjufzrxpufdkijepwpwupdsddjdbpst ON public.usergroups USING btree (handle);


--
-- Name: idx_axiazgpeqnbbyqvovgdvqvzizxkohrrzgnzw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_axiazgpeqnbbyqvovgdvqvzizxkohrrzgnzw ON public.announcements USING btree ("dateRead");


--
-- Name: idx_axzihtkodnkezysqcqhaecqwqzmiucdutxwf; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_axzihtkodnkezysqcqhaecqwqzmiucdutxwf ON public.structureelements USING btree (level);


--
-- Name: idx_ayabjuuxmnulmhasciovdnjppwsxhhotarls; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ayabjuuxmnulmhasciovdnjppwsxhhotarls ON public.users USING btree (lower((email)::text));


--
-- Name: idx_azjjvhabyxauuoervdzgjjpoyrpqwsxgsxxe; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_azjjvhabyxauuoervdzgjjpoyrpqwsxgsxxe ON public.structures USING btree ("dateDeleted");


--
-- Name: idx_babhzltkcwbilmiubdfkxfoozsnnpsvoijly; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_babhzltkcwbilmiubdfkxfoozsnnpsvoijly ON public.elements USING btree (archived, "dateCreated");


--
-- Name: idx_bilcggtnsoktnmmhkrpqbrjfgjrowqpzbjbi; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_bilcggtnsoktnmmhkrpqbrjfgjrowqpzbjbi ON public.sessions USING btree ("userId");


--
-- Name: idx_bttzbncolqelxdvsehvyseuwaajegalmoeiu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_bttzbncolqelxdvsehvyseuwaajegalmoeiu ON public.elements USING btree ("fieldLayoutId");


--
-- Name: idx_bwjctxecagvvdbfkmiifiqxxrbbiwrovajhw; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_bwjctxecagvvdbfkmiifiqxxrbbiwrovajhw ON public.migrations USING btree (track, name);


--
-- Name: idx_cvrndkwwujgngbxsyzeiwonhbblmntvivotm; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_cvrndkwwujgngbxsyzeiwonhbblmntvivotm ON public.fieldlayoutfields USING btree ("sortOrder");


--
-- Name: idx_cydqleehfvxynixrqisfzcwulatqefelmgbq; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_cydqleehfvxynixrqisfzcwulatqefelmgbq ON public.content USING btree ("elementId", "siteId");


--
-- Name: idx_czjxsohtcyylerfklnanwfvtsxaauofzjzob; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_czjxsohtcyylerfklnanwfvtsxaauofzjzob ON public.queue USING btree (channel, fail, "timeUpdated", delay);


--
-- Name: idx_czzjzdtomdbbpnofjxzasjcfcccaulwregob; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_czzjzdtomdbbpnofjxzasjcfcccaulwregob ON public.fieldgroups USING btree (name);


--
-- Name: idx_dadllcbvbexzqnwnztleqhekpmvjarmqbwnb; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dadllcbvbexzqnwnztleqhekpmvjarmqbwnb ON public.entrytypes USING btree ("fieldLayoutId");


--
-- Name: idx_damcsuiuwyyhxrkureimwuachbdantxivecs; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_damcsuiuwyyhxrkureimwuachbdantxivecs ON public.structureelements USING btree (root);


--
-- Name: idx_dbnnqajitnuvoqoxyoysnpgzjcrtulazsjnw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dbnnqajitnuvoqoxyoysnpgzjcrtulazsjnw ON public.sessions USING btree (token);


--
-- Name: idx_dgfkyrppyhtfbqsgyzqidhgkbyadhfrnztwx; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_dgfkyrppyhtfbqsgyzqidhgkbyadhfrnztwx ON public.plugins USING btree (handle);


--
-- Name: idx_dlrwtdumpvlxzixywbjqiqvouhgdqaauhdie; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dlrwtdumpvlxzixywbjqiqvouhgdqaauhdie ON public.structureelements USING btree (rgt);


--
-- Name: idx_dlzzcnuwfmhkkazjleroldkqczqofupgaefy; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dlzzcnuwfmhkkazjleroldkqczqofupgaefy ON public.sites USING btree ("dateDeleted");


--
-- Name: idx_dshrjjinkykfhodhddnvluepibyopuoqmlzf; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_dshrjjinkykfhodhddnvluepibyopuoqmlzf ON public.shunnedmessages USING btree ("userId", message);


--
-- Name: idx_dwdxrofgkcintntktqjfjzvlrlobbjyzmekp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dwdxrofgkcintntktqjfjzvlrlobbjyzmekp ON public.sites USING btree ("sortOrder");


--
-- Name: idx_dwjxqkbbpltwoisgyycbzbuzzcirrnstlmtk; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_dwjxqkbbpltwoisgyycbzbuzzcirrnstlmtk ON public.revisions USING btree ("canonicalId", num);


--
-- Name: idx_dwycallolfibvfjbmhxunawnoqstprtatstg; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dwycallolfibvfjbmhxunawnoqstprtatstg ON public.categorygroups USING btree (name);


--
-- Name: idx_dxjlpxhcacooflunyhiiiztsfdkthdrmaqwv; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_dxjlpxhcacooflunyhiiiztsfdkthdrmaqwv ON public.taggroups USING btree ("dateDeleted");


--
-- Name: idx_ebedtwdldluqbevtndhyqpuyowhrukgqmqky; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ebedtwdldluqbevtndhyqpuyowhrukgqmqky ON public.taggroups USING btree (handle);


--
-- Name: idx_ejdmgqxczpnrkfqjedrvlyethronhlwkqaca; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ejdmgqxczpnrkfqjedrvlyethronhlwkqaca ON public.entrytypes USING btree ("dateDeleted");


--
-- Name: idx_ekzfwcnzoanhtdyqikyqqkgwmijuuponskmt; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ekzfwcnzoanhtdyqikyqqkgwmijuuponskmt ON public.fieldlayouttabs USING btree ("layoutId");


--
-- Name: idx_eqwmsepcggoqmzrnvvcozyeiibtbqejlwvek; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_eqwmsepcggoqmzrnvvcozyeiibtbqejlwvek ON public.assets USING btree ("volumeId");


--
-- Name: idx_eukjnwpumnpztrptslxovgdvokvpfeweaugw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_eukjnwpumnpztrptslxovgdvokvpfeweaugw ON public.volumes USING btree ("dateDeleted");


--
-- Name: idx_euwzjsumpayrzyusaylsebogaoocwxfyadff; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_euwzjsumpayrzyusaylsebogaoocwxfyadff ON public.entrytypes USING btree ("sectionId");


--
-- Name: idx_ewvmctgtklfrlbohamgitxyykbwxgdkdusfp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ewvmctgtklfrlbohamgitxyykbwxgdkdusfp ON public.widgets USING btree ("userId");


--
-- Name: idx_faayjxnrgswbfckqzntktodhojgvibemqtch; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_faayjxnrgswbfckqzntktodhojgvibemqtch ON public.tags USING btree ("groupId");


--
-- Name: idx_fazqyxqhgeyazlhchrvsofcktpdfccyqwdho; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fazqyxqhgeyazlhchrvsofcktpdfccyqwdho ON public.fields USING btree ("groupId");


--
-- Name: idx_fbsttcrbmfdptdguqqkxpuvvlruszknjobkv; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fbsttcrbmfdptdguqqkxpuvvlruszknjobkv ON public.users USING btree ("verificationCode");


--
-- Name: idx_fdfasfwelskedcvnevavdhlusygzceiyqlch; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_fdfasfwelskedcvnevavdhlusygzceiyqlch ON public.userpermissions_usergroups USING btree ("permissionId", "groupId");


--
-- Name: idx_fhvqhtpkrzvfquvasfydnauuxdronjbejqlz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fhvqhtpkrzvfquvasfydnauuxdronjbejqlz ON public.sections USING btree (handle);


--
-- Name: idx_fojcxcfeclcxhvgghhmhgdnekgfscjhydztv; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fojcxcfeclcxhvgghhmhgdnekgfscjhydztv ON public.entries USING btree ("sectionId");


--
-- Name: idx_fqlhbhbhrcxquaowthijouijthlhxwfryacn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fqlhbhbhrcxquaowthijouijthlhxwfryacn ON public.relations USING btree ("sourceSiteId");


--
-- Name: idx_fqnrnadsqursdtrdlnlrhwknmwtokeqobaof; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_fqnrnadsqursdtrdlnlrhwknmwtokeqobaof ON public.content USING btree ("siteId");


--
-- Name: idx_gjniflxxesahanioqhgatypkwmhasndjcwqd; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_gjniflxxesahanioqhgatypkwmhasndjcwqd ON public.tokens USING btree ("expiryDate");


--
-- Name: idx_gncdkkxxuzdxirnetnruebclqgapsmzgnued; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_gncdkkxxuzdxirnetnruebclqgapsmzgnued ON public.users USING btree (lower((username)::text));


--
-- Name: idx_gvwfmdkkwhvotvbyuylpegwxezfegehjrlxn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_gvwfmdkkwhvotvbyuylpegwxezfegehjrlxn ON public.sites USING btree (handle);


--
-- Name: idx_gvypkfsyviwtmaeuzteczdqnkdovtsipbxsl; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_gvypkfsyviwtmaeuzteczdqnkdovtsipbxsl ON public.entries USING btree ("authorId");


--
-- Name: idx_gypcqodlqegxkowngbvnrxisbftfvsiirlef; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_gypcqodlqegxkowngbvnrxisbftfvsiirlef ON public.assets USING btree (filename, "folderId");


--
-- Name: idx_heucnkzckcqvkxtnrwqrseltthqxklzeojqz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_heucnkzckcqvkxtnrwqrseltthqxklzeojqz ON public.categorygroups USING btree ("structureId");


--
-- Name: idx_hhgzblsifsgdzmxbloqwldrseqwzunajuwoe; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_hhgzblsifsgdzmxbloqwldrseqwzunajuwoe ON public.gqltokens USING btree (name);


--
-- Name: idx_hpmtbprxzaedivvpiycnheskpwtazbaclebh; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_hpmtbprxzaedivvpiycnheskpwtazbaclebh ON public.entries USING btree ("expiryDate");


--
-- Name: idx_htznodptdjvadfbyziokqdagojxvgpfmmtxz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_htznodptdjvadfbyziokqdagojxvgpfmmtxz ON public.relations USING btree ("sourceId");


--
-- Name: idx_hxwmuumnidzsmuaodjkdndznkuqgiupcvymn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_hxwmuumnidzsmuaodjkdndznkuqgiupcvymn ON public.searchindex USING gin (keywords_vector) WITH (fastupdate=yes);


--
-- Name: idx_ijfmzvugdfwyiyoqdorvvnyoghutkxbwsfvj; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ijfmzvugdfwyiyoqdorvvnyoghutkxbwsfvj ON public.imagetransforms USING btree (handle);


--
-- Name: idx_imqnfkutmktrdxdntseyqkywcttxwshzxtbe; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_imqnfkutmktrdxdntseyqkywcttxwshzxtbe ON public.elements USING btree (archived, "dateDeleted", "draftId", "revisionId", "canonicalId");


--
-- Name: idx_irkmpnsgdjojqexcfevdqwaevvjgslnkrmnc; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_irkmpnsgdjojqexcfevdqwaevvjgslnkrmnc ON public.matrixblocktypes USING btree (name, "fieldId");


--
-- Name: idx_itkbkrifumwdrpmygbtfvmdmtlthcelrkrxk; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_itkbkrifumwdrpmygbtfvmdmtlthcelrkrxk ON public.usergroups_users USING btree ("groupId", "userId");


--
-- Name: idx_ivysopmkmggqmjskofqwhpzbodovpoifbosx; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_ivysopmkmggqmjskofqwhpzbodovpoifbosx ON public.volumefolders USING btree (name, "parentId", "volumeId");


--
-- Name: idx_iydmtaasphcteupifmizmzaffqrmhtfpbvdg; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_iydmtaasphcteupifmizmzaffqrmhtfpbvdg ON public.entries USING btree ("postDate");


--
-- Name: idx_jcfieqlcabaqqovjcxurbdlplbgqnuowodeq; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_jcfieqlcabaqqovjcxurbdlplbgqnuowodeq ON public.elements USING btree (type);


--
-- Name: idx_jlumnvwymecendyaobjzddujpflidvfzqgwd; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_jlumnvwymecendyaobjzddujpflidvfzqgwd ON public.structureelements USING btree ("structureId", "elementId");


--
-- Name: idx_kewinfrnprwzovztfqojdgolfulimtfqthgq; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_kewinfrnprwzovztfqojdgolfulimtfqthgq ON public.fields USING btree (context);


--
-- Name: idx_khrnhjxzzjesygbwtowehlvvvzwubxpwmcao; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_khrnhjxzzjesygbwtowehlvvvzwubxpwmcao ON public.sitegroups USING btree (name);


--
-- Name: idx_kkpkgcfjicyljuucrykktcorfqfrlhizltef; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_kkpkgcfjicyljuucrykktcorfqfrlhizltef ON public.globalsets USING btree (handle);


--
-- Name: idx_kxhjoyiqoeuycelcrvswzdyxnfinvqmhdtdw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_kxhjoyiqoeuycelcrvswzdyxnfinvqmhdtdw ON public.fieldlayoutfields USING btree ("tabId");


--
-- Name: idx_lhfpqrrybotxncannxvtpzqedpteqycbrqjp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_lhfpqrrybotxncannxvtpzqedpteqycbrqjp ON public.fieldlayouttabs USING btree ("sortOrder");


--
-- Name: idx_llkmegywfvfaamrxndmoxallikkdnljepxgp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_llkmegywfvfaamrxndmoxallikkdnljepxgp ON public.elements_sites USING btree (lower((uri)::text), "siteId");


--
-- Name: idx_lpoczuhmpwpxnxvhzsdndhkejbbmlnvwzvml; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_lpoczuhmpwpxnxvhzsdndhkejbbmlnvwzvml ON public.users USING btree (locked);


--
-- Name: idx_lsgtsooludrtbsxqpndcqkevbaphgjuarkvn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_lsgtsooludrtbsxqpndcqkevbaphgjuarkvn ON public.changedattributes USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_lvvdluxfimmuwmhomfjitierkgdqxixvuvcp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_lvvdluxfimmuwmhomfjitierkgdqxixvuvcp ON public.sessions USING btree (uid);


--
-- Name: idx_lxpramyjisixogcluqevkuomkmsawmgzxavu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_lxpramyjisixogcluqevkuomkmsawmgzxavu ON public.fieldgroups USING btree ("dateDeleted", name);


--
-- Name: idx_mdvzvhjdvtthbgajxfzjtsujtltzgbhotavn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_mdvzvhjdvtthbgajxfzjtsujtltzgbhotavn ON public.categories USING btree ("groupId");


--
-- Name: idx_mecghxsbrlhejstkqljzyfwctvggaokmmwpf; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_mecghxsbrlhejstkqljzyfwctvggaokmmwpf ON public.fields USING btree (handle, context);


--
-- Name: idx_meeozhsexmcqtfaydzimygdhboskopfiagqh; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_meeozhsexmcqtfaydzimygdhboskopfiagqh ON public.matrixblocktypes USING btree ("fieldLayoutId");


--
-- Name: idx_mguknskyftkwkukewnrdkxryjeadwoungwdv; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_mguknskyftkwkukewnrdkxryjeadwoungwdv ON public.deprecationerrors USING btree (key, fingerprint);


--
-- Name: idx_mhoabbllsvskcimgzugdrzurgwtziytzjtdp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_mhoabbllsvskcimgzugdrzurgwtziytzjtdp ON public.entries USING btree ("typeId");


--
-- Name: idx_mhpqrijnogrnrximcdrdzdarhnoqsqxquusc; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_mhpqrijnogrnrximcdrdzdarhnoqsqxquusc ON public.changedfields USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_ngnsnqcikbvsthzzjlawwsaglfvsvczspfku; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ngnsnqcikbvsthzzjlawwsaglfvsvczspfku ON public.matrixblocktypes USING btree (handle, "fieldId");


--
-- Name: idx_nlibrcxmxsdvyjmzcmxehwxihcelrbgphrzb; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_nlibrcxmxsdvyjmzcmxehwxihcelrbgphrzb ON public.volumes USING btree ("fieldLayoutId");


--
-- Name: idx_nlymydmxixdrnpzanvdfhvfmyusamsxdwpnt; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_nlymydmxixdrnpzanvdfhvfmyusamsxdwpnt ON public.matrixblocks USING btree ("fieldId");


--
-- Name: idx_nswlmqtrauxanaridledzpntgsarhtebceqg; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_nswlmqtrauxanaridledzpntgsarhtebceqg ON public.userpermissions_users USING btree ("userId");


--
-- Name: idx_ntmppperkjcklxjiqxnjxxctpciojkwmshmt; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ntmppperkjcklxjiqxnjxxctpciojkwmshmt ON public.volumes USING btree (name);


--
-- Name: idx_oqdggpljmxnmdyjhckzxqyyudruqzvkcpacl; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_oqdggpljmxnmdyjhckzxqyyudruqzvkcpacl ON public.sections USING btree ("structureId");


--
-- Name: idx_otvkqotpnflucsqxtpfrxmegzkealgeevfau; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_otvkqotpnflucsqxtpfrxmegzkealgeevfau ON public.sections_sites USING btree ("sectionId", "siteId");


--
-- Name: idx_oxiokoclsufnqnlntmaxorudpvcpisarfspj; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_oxiokoclsufnqnlntmaxorudpvcpisarfspj ON public.relations USING btree ("fieldId", "sourceId", "sourceSiteId", "targetId");


--
-- Name: idx_oyeufxjgmbmdjeckjpktfbcfsnwmorkdssst; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_oyeufxjgmbmdjeckjpktfbcfsnwmorkdssst ON public.userpermissions_usergroups USING btree ("groupId");


--
-- Name: idx_pamykwszzyviwgbimksacpfvmtvhqoiwbflf; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_pamykwszzyviwgbimksacpfvmtvhqoiwbflf ON public.elements_sites USING btree ("elementId", "siteId");


--
-- Name: idx_pjegkcbwxxbfxruoeyzbwcsxufxftajkunbe; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_pjegkcbwxxbfxruoeyzbwcsxufxftajkunbe ON public.elements_sites USING btree (slug, "siteId");


--
-- Name: idx_pqvspzzaplptimjhefzxhfjnxldoflwgwcvp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_pqvspzzaplptimjhefzxhfjnxldoflwgwcvp ON public.globalsets USING btree (name);


--
-- Name: idx_pxnhehwlvbgrghkcdcnhncduuqtvyjupmdco; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_pxnhehwlvbgrghkcdcnhncduuqtvyjupmdco ON public.taggroups USING btree (name);


--
-- Name: idx_qcxiexquqfwnnwpaootonppfhdgavfgtkomx; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_qcxiexquqfwnnwpaootonppfhdgavfgtkomx ON public.assets USING btree ("folderId");


--
-- Name: idx_qdrpexvckchzjdzhbhgjdnjvkwpwxluxhijh; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_qdrpexvckchzjdzhbhgjdnjvkwpwxluxhijh ON public.users USING btree (active);


--
-- Name: idx_qlakiemsvicvrprqodomnktnjzujpuibkdcu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_qlakiemsvicvrprqodomnktnjzujpuibkdcu ON public.searchindex USING btree (keywords);


--
-- Name: idx_qlsngwtdqfjjuthldahyizrznkzscculbigd; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_qlsngwtdqfjjuthldahyizrznkzscculbigd ON public.assetindexdata USING btree ("volumeId");


--
-- Name: idx_qwxpfwdmqolgfdjagqfqdsoclobirwoqptct; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_qwxpfwdmqolgfdjagqfqdsoclobirwoqptct ON public.gqltokens USING btree ("accessToken");


--
-- Name: idx_rdxykdbuxtqtnleesxrbwnjplropjjjzgguq; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_rdxykdbuxtqtnleesxrbwnjplropjjjzgguq ON public.users USING btree (pending);


--
-- Name: idx_revsgjoekannpjkfatdjrekgjuvnioeztlfw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_revsgjoekannpjkfatdjrekgjuvnioeztlfw ON public.content USING btree (title);


--
-- Name: idx_rllqiaqmuxmejsygatvswigliamhihcdwwxh; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_rllqiaqmuxmejsygatvswigliamhihcdwwxh ON public.assetindexdata USING btree ("sessionId", "volumeId");


--
-- Name: idx_scvhqjzolilhywcbcqbaswllmcugisgblqdx; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_scvhqjzolilhywcbcqbaswllmcugisgblqdx ON public.matrixblocks USING btree ("primaryOwnerId");


--
-- Name: idx_sdrnbscxkhjoegxgraggrpmiyaxkbcimnvox; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_sdrnbscxkhjoegxgraggrpmiyaxkbcimnvox ON public.structureelements USING btree (lft);


--
-- Name: idx_segpbrrfuqqglritcjfcuhudrugcjdcjkryz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_segpbrrfuqqglritcjfcuhudrugcjdcjkryz ON public.entrytypes USING btree (name, "sectionId");


--
-- Name: idx_siciqbducnbchrcpelayurgafduutebgkrfp; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_siciqbducnbchrcpelayurgafduutebgkrfp ON public.userpermissions USING btree (name);


--
-- Name: idx_slgdfdfmiggajzyeqqypiioxdmaxlvzdtgec; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_slgdfdfmiggajzyeqqypiioxdmaxlvzdtgec ON public.categorygroups USING btree ("dateDeleted");


--
-- Name: idx_tcmbvzdaelnfcinbpnxkpqkduhmlxlahoccu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_tcmbvzdaelnfcinbpnxkpqkduhmlxlahoccu ON public.drafts USING btree (saved);


--
-- Name: idx_thxxhvwizymluiznwotvellvqizxdcctuzoe; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_thxxhvwizymluiznwotvellvqizxdcctuzoe ON public.fieldlayoutfields USING btree ("layoutId", "fieldId");


--
-- Name: idx_tiqhrebdryxqgpnuggutzczwqeqawnkfssys; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_tiqhrebdryxqgpnuggutzczwqeqawnkfssys ON public.elements USING btree (enabled);


--
-- Name: idx_tnzvgjvdpudecaxtxqalppadxdlnvuvuubdl; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_tnzvgjvdpudecaxtxqalppadxdlnvuvuubdl ON public.categorygroups USING btree ("fieldLayoutId");


--
-- Name: idx_tsqucgrfnqruqlfqzrhbyyscuodlafukbpsz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_tsqucgrfnqruqlfqzrhbyyscuodlafukbpsz ON public.imagetransformindex USING btree ("assetId", "transformString");


--
-- Name: idx_tssymcbdgbzuepgprljnihiwasgjsbieysuc; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_tssymcbdgbzuepgprljnihiwasgjsbieysuc ON public.categorygroups_sites USING btree ("groupId", "siteId");


--
-- Name: idx_tvmnwpiiacdnudbzinievopszbptjtunyqsy; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_tvmnwpiiacdnudbzinievopszbptjtunyqsy ON public.elements USING btree ("dateDeleted");


--
-- Name: idx_txikxsazpatxmpahnuhwaojcttmzhgefdjrd; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_txikxsazpatxmpahnuhwaojcttmzhgefdjrd ON public.fieldlayouts USING btree (type);


--
-- Name: idx_ujurnizwdiogtsijplktmefcwfohfcjqpqfc; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ujurnizwdiogtsijplktmefcwfohfcjqpqfc ON public.users USING btree (suspended);


--
-- Name: idx_ulkbxnynzzunpmwswruelxyjnklvwvfouzek; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ulkbxnynzzunpmwswruelxyjnklvwvfouzek ON public.elements_sites USING btree ("siteId");


--
-- Name: idx_uxwgnmmpkbqzxsvgztslobvbvimbiakpicqx; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_uxwgnmmpkbqzxsvgztslobvbvimbiakpicqx ON public.sessions USING btree ("dateUpdated");


--
-- Name: idx_uyguvtqbqhadijmdfgopewddgnopvjukcebj; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_uyguvtqbqhadijmdfgopewddgnopvjukcebj ON public.globalsets USING btree ("sortOrder");


--
-- Name: idx_vhnlaxdwxyiwnpwmidoxrsfhmsoqnzqxlmka; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_vhnlaxdwxyiwnpwmidoxrsfhmsoqnzqxlmka ON public.elements_sites USING btree (enabled);


--
-- Name: idx_vxzccobhxpgksuknsozixlbitdnubfcltoru; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_vxzccobhxpgksuknsozixlbitdnubfcltoru ON public.usergroups USING btree (name);


--
-- Name: idx_wdfcmbgfqqdfrqwrzdxiuqsyxoamilbdcuzw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wdfcmbgfqqdfrqwrzdxiuqsyxoamilbdcuzw ON public.matrixblocktypes USING btree ("fieldId");


--
-- Name: idx_wfaaircgwfopniwaftgwcelrhkwcrrxmcvva; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wfaaircgwfopniwaftgwcelrhkwcrrxmcvva ON public.announcements USING btree ("userId", unread, "dateRead", "dateCreated");


--
-- Name: idx_wmbgwpvzskysjcmhqjrbonmnhnmyclrmyrls; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wmbgwpvzskysjcmhqjrbonmnhnmyclrmyrls ON public.sections USING btree (name);


--
-- Name: idx_wrybzqylueecgdskihessacmimmeadrzgfdi; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wrybzqylueecgdskihessacmimmeadrzgfdi ON public.structureelements USING btree ("elementId");


--
-- Name: idx_wsipcjvuksbgfqmtzbnddedajegyxpptsovu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wsipcjvuksbgfqmtzbnddedajegyxpptsovu ON public.relations USING btree ("targetId");


--
-- Name: idx_wymeevpqwnjcgqeeozesbbqgdeacxgnxvnbr; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wymeevpqwnjcgqeeozesbbqgdeacxgnxvnbr ON public.elements USING btree (archived, "dateDeleted", "draftId", "revisionId", "canonicalId", enabled);


--
-- Name: idx_wysidjvkqkjgqbcwqgaqczzbzqpoolanwtrp; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_wysidjvkqkjgqbcwqgaqczzbzqpoolanwtrp ON public.sections USING btree ("dateDeleted");


--
-- Name: idx_yagdxofyfjdxhhwyilrzrwsrrjilkiqwssdd; Type: INDEX; Schema: public; Owner: db
--

CREATE UNIQUE INDEX idx_yagdxofyfjdxhhwyilrzrwsrrjilkiqwssdd ON public.userpermissions_users USING btree ("permissionId", "userId");


--
-- Name: idx_ydwtbswsknggvxmckmphoydjrxiduvmcrbwn; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ydwtbswsknggvxmckmphoydjrxiduvmcrbwn ON public.volumes USING btree (handle);


--
-- Name: idx_ygtahszdfgyncdhtviyncjrjffouwgdgrbiz; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ygtahszdfgyncdhtviyncjrjffouwgdgrbiz ON public.volumefolders USING btree ("volumeId");


--
-- Name: idx_ypiejtdboleflupbohugvrznwjenxfrrcmcw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ypiejtdboleflupbohugvrznwjenxfrrcmcw ON public.systemmessages USING btree (language);


--
-- Name: idx_ytdjcdnlrhicggwsjmoipqeryjdbnfyrxlsg; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ytdjcdnlrhicggwsjmoipqeryjdbnfyrxlsg ON public.fieldlayoutfields USING btree ("fieldId");


--
-- Name: idx_ywfbdrcpxldozsuzvjohdifalhzjvjjljbyw; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ywfbdrcpxldozsuzvjohdifalhzjvjjljbyw ON public.imagetransforms USING btree (name);


--
-- Name: idx_yxfqowkpzhfzrdbyajgllmbnanbtmjbvohxl; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_yxfqowkpzhfzrdbyajgllmbnanbtmjbvohxl ON public.categorygroups USING btree (handle);


--
-- Name: idx_ziieopipufiqrlanxgcfrayrmldabhhyddbu; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ziieopipufiqrlanxgcfrayrmldabhhyddbu ON public.entrytypes USING btree (handle, "sectionId");


--
-- Name: idx_zpfnqdxcayfvdnyerdgehfobfoxsrmlgbpuo; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_zpfnqdxcayfvdnyerdgehfobfoxsrmlgbpuo ON public.sections_sites USING btree ("siteId");


--
-- Name: idx_zrwhgptynxwtfxlpwfmovbqsktctoeafjgot; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_zrwhgptynxwtfxlpwfmovbqsktctoeafjgot ON public.usergroups_users USING btree ("userId");


--
-- Name: idx_zssegperhzhovloqsemtockxztwsbalbjsxm; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_zssegperhzhovloqsemtockxztwsbalbjsxm ON public.globalsets USING btree ("fieldLayoutId");


--
-- Name: idx_ztgpeqzgibnreorbjwmqldjmudugzugufkxf; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ztgpeqzgibnreorbjwmqldjmudugzugufkxf ON public.volumefolders USING btree ("parentId");


--
-- Name: idx_ztvuhfpqqyjmntzskiiixmpwxicfinvbibig; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_ztvuhfpqqyjmntzskiiixmpwxicfinvbibig ON public.queue USING btree (channel, fail, "timeUpdated", "timePushed");


--
-- Name: idx_zxdioutmfqpcshylllzcrsjstyrocwjiurfk; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_zxdioutmfqpcshylllzcrsjstyrocwjiurfk ON public.categorygroups_sites USING btree ("siteId");


--
-- Name: idx_zzvunedaadpgujnvkpdkvdsimemtuaosduzv; Type: INDEX; Schema: public; Owner: db
--

CREATE INDEX idx_zzvunedaadpgujnvkpdkvdsimemtuaosduzv ON public.drafts USING btree ("creatorId", provisional);


--
-- Name: content fk_aandfhquatrvdaqgvflpeqvcstwurqdtrzra; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_aandfhquatrvdaqgvflpeqvcstwurqdtrzra FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: relations fk_aiigwhbxdcahroxvaqtfduspltidfkwcwixa; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_aiigwhbxdcahroxvaqtfduspltidfkwcwixa FOREIGN KEY ("targetId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements fk_akcfktiiphocpvirzvzzxhuviuapealshvhw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_akcfktiiphocpvirzvzzxhuviuapealshvhw FOREIGN KEY ("canonicalId") REFERENCES public.elements(id) ON DELETE SET NULL;


--
-- Name: globalsets fk_aqdwnipeheeogcormulsfsdnjcdpqgutpilq; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_aqdwnipeheeogcormulsfsdnjcdpqgutpilq FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: entries fk_bbzftlsakjqwvwrmfsydpkadsubuapcivhpj; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_bbzftlsakjqwvwrmfsydpkadsubuapcivhpj FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: elements fk_bjfwrsyangaciynvkmspvgwtegllaqgrbnxi; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_bjfwrsyangaciynvkmspvgwtegllaqgrbnxi FOREIGN KEY ("revisionId") REFERENCES public.revisions(id) ON DELETE CASCADE;


--
-- Name: volumefolders fk_bmfbwkyxrjncupakxaolpjgbbvgtyxkecnrt; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_bmfbwkyxrjncupakxaolpjgbbvgtyxkecnrt FOREIGN KEY ("parentId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: fields fk_cnxlebhgfhqrqgejvpaukfdkaaurteqvwvib; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fk_cnxlebhgfhqrqgejvpaukfdkaaurteqvwvib FOREIGN KEY ("groupId") REFERENCES public.fieldgroups(id) ON DELETE CASCADE;


--
-- Name: assetindexdata fk_cpqygrgowqqaleiwzimemzadxxchxqkcqlhl; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT fk_cpqygrgowqqaleiwzimemzadxxchxqkcqlhl FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_cvqtokzxppctvzcjxhoieameihlqtlvxcssv; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_cvqtokzxppctvzcjxhoieameihlqtlvxcssv FOREIGN KEY ("typeId") REFERENCES public.matrixblocktypes(id) ON DELETE CASCADE;


--
-- Name: sessions fk_cynydetnqhtaevjovuynmhozjwplghcfagwv; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_cynydetnqhtaevjovuynmhozjwplghcfagwv FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assets fk_dclukjyknmvxjxayklbyzbvrrjlgmzgcuxoy; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_dclukjyknmvxjxayklbyzbvrrjlgmzgcuxoy FOREIGN KEY ("folderId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: craftidtokens fk_driawgzaczmbrorqhzuolihmjwhoegeccebv; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT fk_driawgzaczmbrorqhzuolihmjwhoegeccebv FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_dtzlsstqtsdkhfnlxbehnvzzfdbpmrmdfgts; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_dtzlsstqtsdkhfnlxbehnvzzfdbpmrmdfgts FOREIGN KEY ("primaryOwnerId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: categorygroups fk_dvhcqkrvyhaqwbclhyaaantljsmpuuantmqf; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_dvhcqkrvyhaqwbclhyaaantljsmpuuantmqf FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: drafts fk_elwregzndejiahxokekegovnagpxxikybozz; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_elwregzndejiahxokekegovnagpxxikybozz FOREIGN KEY ("canonicalId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: userpermissions_usergroups fk_ensgrxhhzslytyqutxezreydbjdfqqpbbjdr; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_ensgrxhhzslytyqutxezreydbjdfqqpbbjdr FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: categorygroups_sites fk_evbtiledwjdrnxmsdfmeeodnrduwxvlzfque; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_evbtiledwjdrnxmsdfmeeodnrduwxvlzfque FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: elements fk_evdtdjufawqhgijgqwentubjzifytnreycmh; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_evdtdjufawqhgijgqwentubjzifytnreycmh FOREIGN KEY ("draftId") REFERENCES public.drafts(id) ON DELETE CASCADE;


--
-- Name: users fk_feaderspvkehbtioqusplnzskmzvhncxhjtr; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_feaderspvkehbtioqusplnzskmzvhncxhjtr FOREIGN KEY ("photoId") REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: volumefolders fk_femfwoqyfptxnmqkpwlutogtohqugdukmfpx; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_femfwoqyfptxnmqkpwlutogtohqugdukmfpx FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_flzeeetccxfbqdbuopmrcjydcynqcwotcsmf; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_flzeeetccxfbqdbuopmrcjydcynqcwotcsmf FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assets fk_fujrtehrmwtcvlrvlicoslayeqflewqzsrbx; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_fujrtehrmwtcvlrvlicoslayeqflewqzsrbx FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: sections_sites fk_fzrjbbxeeqcwdogotsudqoqzeqtzdnqofjht; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_fzrjbbxeeqcwdogotsudqoqzeqtzdnqofjht FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: revisions fk_gdyqfjihswehatbodxeliaxrwzfmffxgfkhn; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_gdyqfjihswehatbodxeliaxrwzfmffxgfkhn FOREIGN KEY ("canonicalId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_glfjrelpwlafqdsfbodysrqoycjzrdmgqxoh; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_glfjrelpwlafqdsfbodysrqoycjzrdmgqxoh FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: globalsets fk_gllgihxdaldhhgzirikeqtwhyssmmlwhtbqu; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_gllgihxdaldhhgzirikeqtwhyssmmlwhtbqu FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: matrixblocks_owners fk_gmiwiagxwpodqbduzcjctiicaycdirwplogy; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks_owners
    ADD CONSTRAINT fk_gmiwiagxwpodqbduzcjctiicaycdirwplogy FOREIGN KEY ("ownerId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: userpreferences fk_gnobxwmnycakpyxmybqppbyydtwfqianoynz; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT fk_gnobxwmnycakpyxmybqppbyydtwfqianoynz FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_gozvjkaqbyxzofwxsqxgfsdjvajdnkegompa; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_gozvjkaqbyxzofwxsqxgfsdjvajdnkegompa FOREIGN KEY ("tabId") REFERENCES public.fieldlayouttabs(id) ON DELETE CASCADE;


--
-- Name: changedattributes fk_gqxsqzbrnipbyjomtjlkbwjyauvjgdxujoqv; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_gqxsqzbrnipbyjomtjlkbwjyauvjgdxujoqv FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: entrytypes fk_gvloabihmxslblvbqixgeglpweqsgxxwqkaw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_gvloabihmxslblvbqixgeglpweqsgxxwqkaw FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: drafts fk_gyzvvavwrzhfcvufwkcrfnhahmezqpmcqjkd; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_gyzvvavwrzhfcvufwkcrfnhahmezqpmcqjkd FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: entrytypes fk_hcademuikyudzlegynpmwejxbzyappxmzkbl; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_hcademuikyudzlegynpmwejxbzyappxmzkbl FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: shunnedmessages fk_hzpwnmrjztalzdfefxuarcitmngvkmpezmxk; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT fk_hzpwnmrjztalzdfefxuarcitmngvkmpezmxk FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_ibhywwxdpwplqbhzucixdqwyryzuczqmuprc; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_ibhywwxdpwplqbhzucixdqwyryzuczqmuprc FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_iewxkpwyzzlqmkqmuvinizuqlikkpyrrrton; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_iewxkpwyzzlqmkqmuvinizuqlikkpyrrrton FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users fk_iqvuncmawtyckgndahrgpitkhxqhtrkndjhi; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_iqvuncmawtyckgndahrgpitkhxqhtrkndjhi FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: revisions fk_jammzxmrrvffiscmqxawlvhuuzarvmzfscyq; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_jammzxmrrvffiscmqxawlvhuuzarvmzfscyq FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: changedattributes fk_jhqzssexygjxpaptmjivesjwdbxlcofyilpl; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_jhqzssexygjxpaptmjivesjwdbxlcofyilpl FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: widgets fk_klphaslqqiifodtklzdddhyitradaacltelj; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT fk_klphaslqqiifodtklzdddhyitradaacltelj FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories fk_klxsoojmfpncepslrnmyvbplpiurdmbpyjvc; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_klxsoojmfpncepslrnmyvbplpiurdmbpyjvc FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: sites fk_lhxixmvgqcjnafpajpdcyiekyzzfnoiwmjqa; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT fk_lhxixmvgqcjnafpajpdcyiekyzzfnoiwmjqa FOREIGN KEY ("groupId") REFERENCES public.sitegroups(id) ON DELETE CASCADE;


--
-- Name: usergroups_users fk_lkmvaiihdotywcgumjuyopunpljoyewxsngj; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_lkmvaiihdotywcgumjuyopunpljoyewxsngj FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: addresses fk_lndfafnlcdenusthphrhtqtktgrrsdgnnrop; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT fk_lndfafnlcdenusthphrhtqtktgrrsdgnnrop FOREIGN KEY ("ownerId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: entries fk_lqxfkonwdebiyseiddqbgyildobdzbsnxjul; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_lqxfkonwdebiyseiddqbgyildobdzbsnxjul FOREIGN KEY ("authorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tags fk_mcfuyolinrjdtobfmjzwnlmkietjpvtlsnle; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_mcfuyolinrjdtobfmjzwnlmkietjpvtlsnle FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: tags fk_miamxyupygcgdgdvsxwybsdioihyzkotexbf; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_miamxyupygcgdgdvsxwybsdioihyzkotexbf FOREIGN KEY ("groupId") REFERENCES public.taggroups(id) ON DELETE CASCADE;


--
-- Name: relations fk_mjjlfefvneytrazmjaaanmrvicwrwuuemsdk; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_mjjlfefvneytrazmjaaanmrvicwrwuuemsdk FOREIGN KEY ("sourceSiteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fieldlayouttabs fk_myykmtwrjhgmnaxggovkbtenaqtljjluguik; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fk_myykmtwrjhgmnaxggovkbtenaqtljjluguik FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: entries fk_mzjaigjmlzyszzifhgpqfenocjfowhhavzog; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_mzjaigjmlzyszzifhgpqfenocjfowhhavzog FOREIGN KEY ("typeId") REFERENCES public.entrytypes(id) ON DELETE CASCADE;


--
-- Name: announcements fk_ndkqyaczlcesrcnkbsqbseqsfcggcakmspqt; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT fk_ndkqyaczlcesrcnkbsqbseqsfcggcakmspqt FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: entries fk_nhumnpdinybadikubhyewmynzbnwwzmzkevf; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_nhumnpdinybadikubhyewmynzbnwwzmzkevf FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: matrixblocks_owners fk_nzbhukcdyuiigcrqbujynfcmrcusidmwicml; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks_owners
    ADD CONSTRAINT fk_nzbhukcdyuiigcrqbujynfcmrcusidmwicml FOREIGN KEY ("blockId") REFERENCES public.matrixblocks(id) ON DELETE CASCADE;


--
-- Name: usergroups_users fk_ocfpedcmtkzvfbyarfauktprffwiavthquif; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_ocfpedcmtkzvfbyarfauktprffwiavthquif FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: assets fk_ocqjadurscidxvpeflhjbipbhdiqslozqsdu; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_ocqjadurscidxvpeflhjbipbhdiqslozqsdu FOREIGN KEY ("uploaderId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: changedfields fk_onjbsmihavbevixfrhetpwcpoklrvvmetogm; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_onjbsmihavbevixfrhetpwcpoklrvvmetogm FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: volumes fk_osmbztuhrxzhywmhvayqvubaqhxvgglqkdzo; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT fk_osmbztuhrxzhywmhvayqvubaqhxvgglqkdzo FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: matrixblocks fk_pgkvjnenxulrofwxppsqwnfbqyfxcomzilus; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_pgkvjnenxulrofwxppsqwnfbqyfxcomzilus FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: categories fk_prqpuyuvqgnrjweirwjqznglkymcknaxvcnb; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_prqpuyuvqgnrjweirwjqznglkymcknaxvcnb FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: userpermissions_users fk_pwlumaclgpmonbpqutkjpdevtgosdjranuwg; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_pwlumaclgpmonbpqutkjpdevtgosdjranuwg FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: content fk_qhzxlfvfhdwwtzwgozixvtjkobmwhcualeyb; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_qhzxlfvfhdwwtzwgozixvtjkobmwhcualeyb FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: elements_sites fk_qvwjlpqdzdvubmuohwrlwuqahdlbjhiojyjw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_qvwjlpqdzdvubmuohwrlwuqahdlbjhiojyjw FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: relations fk_rbevsmifmwdwznfytywlqwuqhbrmzljcpcrg; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_rbevsmifmwdwznfytywlqwuqhbrmzljcpcrg FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: elements fk_rbnwehmffmyupshovqlevanxtjqzrrplvovw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_rbnwehmffmyupshovqlevanxtjqzrrplvovw FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: elements_sites fk_rhcwrdcmpluyhrnswoassrzfgfpzquehfvod; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_rhcwrdcmpluyhrnswoassrzfgfpzquehfvod FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: structureelements fk_rpnahtkwadpkxrgccknfyauxjkalgmfulbsu; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_rpnahtkwadpkxrgccknfyauxjkalgmfulbsu FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: assetindexdata fk_rrqphxmgzjtriiromhnonqvxbpydabhrzqhw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT fk_rrqphxmgzjtriiromhnonqvxbpydabhrzqhw FOREIGN KEY ("sessionId") REFERENCES public.assetindexingsessions(id) ON DELETE CASCADE;


--
-- Name: announcements fk_sdngjtgjgaomyvcsdjbztnswvnzllrkljvmd; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT fk_sdngjtgjgaomyvcsdjbztnswvnzllrkljvmd FOREIGN KEY ("pluginId") REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: assets fk_tcnezlgfreslzviewqlbvgfjpbclqapfbssz; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_tcnezlgfreslzviewqlbvgfjpbclqapfbssz FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: userpermissions_users fk_thzzayiejivciclvuxzfyevojyvtndcnedkx; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_thzzayiejivciclvuxzfyevojyvtndcnedkx FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sections fk_tkqzlkkpukecspzeigxksupanerynxvjdnrt; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT fk_tkqzlkkpukecspzeigxksupanerynxvjdnrt FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE SET NULL;


--
-- Name: entries fk_tpfgeerbxifscdfqzzmsypjmxmcnuvcrtvcr; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_tpfgeerbxifscdfqzzmsypjmxmcnuvcrtvcr FOREIGN KEY ("parentId") REFERENCES public.entries(id) ON DELETE SET NULL;


--
-- Name: changedattributes fk_tqvvhkdzbgaqsfcxdcrqsnweafqlnbgnbtuw; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_tqvvhkdzbgaqsfcxdcrqsnweafqlnbgnbtuw FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: categories fk_ucckznnngufxdoyosjeelhqzsdtpflrjtodd; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_ucckznnngufxdoyosjeelhqzsdtpflrjtodd FOREIGN KEY ("parentId") REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: addresses fk_ufvpzddvedjkpzjmhuclbmunfwuffdwnnljb; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT fk_ufvpzddvedjkpzjmhuclbmunfwuffdwnnljb FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_usfuboeutymmdhbmlidupjjpaqgckgvgcszz; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_usfuboeutymmdhbmlidupjjpaqgckgvgcszz FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sections_sites fk_uvmkvjrsrzyeziyukgkjhijatmtqwofsfjlo; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_uvmkvjrsrzyeziyukgkjhijatmtqwofsfjlo FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categorygroups fk_vlszuxohwffdwkoaufvdgfhprkfncevxdyij; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_vlszuxohwffdwkoaufvdgfhprkfncevxdyij FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: taggroups fk_xxbdctwxrvrgoijeiqpvjldnauivfcadydkz; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT fk_xxbdctwxrvrgoijeiqpvjldnauivfcadydkz FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: categorygroups_sites fk_yjjelevwrlahulikeaxnyyozyytfkymbrcue; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_yjjelevwrlahulikeaxnyyozyytfkymbrcue FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matrixblocktypes fk_yqbypoifewgpgskvmlreelxckxooovctyczr; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_yqbypoifewgpgskvmlreelxckxooovctyczr FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: userpermissions_usergroups fk_ytatgodovfopaqfgntxwhkfnjihfeagfidwj; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_ytatgodovfopaqfgntxwhkfnjihfeagfidwj FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: structureelements fk_yzlmbnakzdybgfxjwstrtvxvhdtvgchknggx; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_yzlmbnakzdybgfxjwstrtvxvhdtvgchknggx FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: matrixblocktypes fk_yzxfyoqafolfrfiodbenbfuxtusqxnlkeijq; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_yzxfyoqafolfrfiodbenbfuxtusqxnlkeijq FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: relations fk_znvmmxcphngoabcyrufqcnnjpgjijqurstiq; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_znvmmxcphngoabcyrufqcnnjpgjijqurstiq FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: gqltokens fk_zuayqdesrfkgdksyidfbvsjuhvyvjsuwokdh; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT fk_zuayqdesrfkgdksyidfbvsjuhvyvjsuwokdh FOREIGN KEY ("schemaId") REFERENCES public.gqlschemas(id) ON DELETE SET NULL;


--
-- Name: fieldlayoutfields fk_zvpiqtijqebsrqbephyluvdfmzeqzwlwgrmq; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_zvpiqtijqebsrqbephyluvdfmzeqzwlwgrmq FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

